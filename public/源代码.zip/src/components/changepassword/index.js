import React,{Component} from 'react';
import {connect} from 'react-redux';
 
import { Form, Button } from 'antd';
const FormItem = Form.Item;

import md5 from "md5";
 
class Changepassword extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="changepassword">
				<div className="title">修改密码</div>
				<Form layout={formLayout}>
					<FormItem label="姓名：" {...formItemLayout} >
						{this.props.userinfo.username}
					</FormItem>
					<FormItem label="手机号码：" {...formItemLayout} >
						{this.props.userinfo.phonenumber}
					</FormItem>
					<FormItem label="请输入原密码：" {...formItemLayout} >
						<input type="password" placeholder="请输入原密码" ref="original"/>
					</FormItem>
					<FormItem label="请输入更改的密码：" {...formItemLayout} >
						<input type="password" placeholder="请输入修改后的密码" ref="wanted"/>
					</FormItem>
					<FormItem {...buttonItemLayout}>
						<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
					</FormItem>
				</Form>
			</section>
			)
	}
	submit(){
		var original = this.refs.original.value ;
		var wanted = this.refs.wanted.value ;
		//判断原密码输入正误
		if(md5(original) == this.props.userinfo.password){
			axios.post('/user/changepassword',{id:this.props.userinfo._id,wanted}).then(res=>{
				alert('修改成功！');
				this.props.history.push('/login');
			});
		}else{
			alert('原密码输入错误！');
		}
	}
}

export default connect(
	(state)=>{
		return {
			userinfo:state.userinfo
		}
	},
	null
	)(Changepassword);