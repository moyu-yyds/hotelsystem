import React,{Component} from "react";
import {connect} from 'react-redux';

import { Form, Button } from 'antd';
const FormItem = Form.Item;

class Checkin extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	componentWillMount(){
		this.props.getallreservation();
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="checkin">
				<div className="title">入住登记</div>
				<Form layout={formLayout}>
					<FormItem label="入住方式：" {...formItemLayout} >
						<select ref="checkin">
							<option value="个人入住">个人入住</option>
							<option value="团体入住">团体入住</option>
						</select>
					</FormItem>
					<FormItem label="是否预定：" {...formItemLayout} >
						<select ref="reservation">
							<option value="未预定">未预定</option>
							<option value="已预定">已预定</option>
						</select>
					</FormItem>
					<FormItem label="预定者姓名：" {...formItemLayout} >
						<input type="text" ref="name" placeholder="预定者姓名"/>
					</FormItem>
					<FormItem label="预定者身份证号码：" {...formItemLayout} >
						<input type="text" ref="cardid" placeholder="预定者身份证号码" />
					</FormItem>
					<FormItem {...buttonItemLayout}>
						<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
					</FormItem>
				</Form>
			</section>
			)
	}
	submit(){
		var checkinway = this.refs.checkin.value;
		var reservation = this.refs.reservation.value;
		var name = this.refs.name.value;
		var cardid = this.refs.cardid.value;
		if(checkinway == '个人入住' && reservation == '未预定'){
			this.props.getallreservationnum(0);
			this.props.history.push('/home/checkinbaseinfo?1');
		}
		if(checkinway == '个人入住' && reservation == '已预定'){
			for(var i = 0 ; i < this.props.allreservation.length ; i++){
				if(name == this.props.allreservation[i].name && cardid == this.props.allreservation[i].cardid && this.props.allreservation[i].state == '预定中' && this.props.allreservation[i].form == '个人预定'){
					var roominfo = [];
					var num = parseInt(this.props.allreservation[i].personumber);
					this.props.getallreservationnum(num);
					for(var j = 0 ; j < this.props.allreservation[i].roominfo.length ; j++){
						roominfo.push(JSON.parse(this.props.allreservation[i].roominfo[j]));
					}
					//改变预定状态
					axios.post('/room/changereservation',{
						state:1,
						id:this.props.allreservation[i]._id
					}).then(res=>{
						this.props.getchosenroom(roominfo);
						this.props.history.push('/home/checkinbaseinfo?2');
					});
					break;
				}
			}
			if(i == this.props.allreservation.length){
				alert('未查询到预定记录！');
			}
		}
		if(checkinway == '团体入住' && reservation == '未预定'){
			this.props.getallreservationnum(0);
			this.props.history.push('/home/checkinbaseinfo?3');
		}
		if(checkinway == '团体入住' && reservation == '已预定'){
			for(var i = 0 ; i < this.props.allreservation.length ; i++){
				if(name == this.props.allreservation[i].name && cardid == this.props.allreservation[i].cardid && this.props.allreservation[i].state == '预定中' && this.props.allreservation[i].form == '团体预定'){
					var roominfo = [];
					var num = parseInt(this.props.allreservation[i].personumber);
					this.props.getallreservationnum(num);
					for(var j = 0 ; j < this.props.allreservation[i].roominfo.length ; j++){
						roominfo.push(JSON.parse(this.props.allreservation[i].roominfo[j]));
					}
					//改变预定状态
					axios.post('/room/changereservation',{
						state:1,
						id:this.props.allreservation[i]._id
					}).then(res=>{
						this.props.getchosenroom(roominfo);
						this.props.history.push('/home/checkinbaseinfo?4');
					});
					break;
				}
			}
			if(i == this.props.allreservation.length){
				alert('未查询到预定记录！');
			}
		}
	}
}

export default connect(
	(state)=>{
		return {
			allreservation:state.allreservation
		}
	},
	{
		getallreservation(){
			return axios.get('/room/allreservation').then(res=>{
				return {
					type:'allreservation',
					payload:res.data
				}
			});
		},
		getchosenroom(data){
			return {
				type:'chosenroom',
				payload:data
			}
		},
		getallreservationnum(num){
			return {
				type:"reservationnum",
				payload:num
			}
		}
	}
	)(Checkin);