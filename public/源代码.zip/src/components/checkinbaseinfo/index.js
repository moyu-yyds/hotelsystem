import React,{Component} from "react";
import {connect} from "react-redux";

import { Form, Button,Table } from 'antd';
const FormItem = Form.Item;

const pagination = {
	pageSize:6
}

class Checkinbaseinfo extends Component{
	constructor(){
		super();
		this.state = {
			type:'个人入住登记',
			num:33,
			formLayout: 'horizontal',
			columns:[
				{
				title: '房间号',
				dataIndex: 'roomid'
				},    	
				{
				title: '房间类型',
				dataIndex: 'roomtype'
				}
			],
			chosenroom:[]
		}
	}
	componentWillMount(){
		if(location.search.substring(1) == 3 || location.search.substring(1) == 44 || location.search.substring(1) == 4){
			this.setState({type:'团体入住登记',num:44});
		}
		if(location.search.substring(1) == 1 || location.search.substring(1) == 2 || location.search.substring(1) == 3 || location.search.substring(1) == 4){
			this.setState({chosenroom:[]});
			this.props.getbasecheckin({});
		}
		if(location.search.substring(1) == 2 || location.search.substring(1) == 4){
			this.props.getbasecheckin({});
		}
		if(location.search.substring(1) == 33 || location.search.substring(1) == 44){
			var chosenroom = [];
			for(var i = 0 ; i < this.props.chosenroom.length ; i++){
				chosenroom.push({
					key:this.props.chosenroom[i]._id,
					roomid:this.props.chosenroom[i].roomid,
					roomtype:this.props.chosenroom[i].roomtype
				});
			}
			this.setState({chosenroom});
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="checkinbaseinfo">
				<div className="title">{this.state.type}</div>  
				<Form layout={formLayout}>
					<FormItem label="入住人数：" {...formItemLayout} >
						<input type="number" ref="num" placeholder={this.props.basecheckin.num?this.props.basecheckin.num:this.props.num}/>
					</FormItem>
					<div className="operation" onClick={this.jumptochoose.bind(this)}>选择房间</div>
					<Table columns={this.state.columns} dataSource={this.state.chosenroom} bordered pagination={pagination}/>
					<FormItem {...buttonItemLayout}>
						<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
					</FormItem>
				</Form>
			</section>
			)
	}
	jumptochoose(){
		if(location.search.substring(1) == 1 || location.search.substring(1) == 3){
			this.props.getbasecheckin({num:this.refs.num.value});
			this.props.history.push(`/home/chooseroom?${this.state.num}`)
		}else{
			alert('已经选择过房间，切勿重复选择！')
		}	
	}
	submit(){
		if(location.search.substring(1) == 1 || location.search.substring(1) == 3){
			alert('尚未选择房间！');
		}
		//个人
		if(location.search.substring(1) == 33 || location.search.substring(1) == 2){
			this.props.getbasecheckin({room:this.props.chosenroom});
			this.props.history.push('/home/personcheckin?1');
		}
		//团体
		if(location.search.substring(1) == 44 || location.search.substring(1) == 4){
			var num = this.refs.num.value ? this.refs.num.value : this.props.basecheckin.num;
			this.props.getbasecheckin({num,room:this.props.chosenroom});
			this.props.history.push('/home/personcheckin?2');
		}
	}
}

export default connect(
	(state)=>{
		return {
			chosenroom:state.chosenroom,
			basecheckin:state.basecheckin,
			num:state.reservationnum
		}
	},
	{
		getbasecheckin(data){
			return {
				type:'basecheckin',
				payload:data
			}
		},
		initchosenroom(){
			return {
				type:'chosenroom',
				payload:[]
			}
		}
	}
	)(Checkinbaseinfo);