import React,{Component} from "react";
import {connect} from "react-redux";

import { Form, Table } from 'antd';
const FormItem = Form.Item;

const pagination = {
	pageSize:6
}

class Checkindetail extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal',
			allperson:[],
			roominfo:[],
			columnone:[
				{
				title:'入住人姓名',
				dataIndex:'name'
				},
				{
				title:'入住人身份证号',
				dataIndex:'cardid'
				}
			],
			columntwo:[
				{
				title:'房间号',
				dataIndex:'roomid'
				},
				{
				title:'房间类型',
				dataIndex:'roomtype'
				}
			]
		}
	}
	componentWillMount(){
		var allperson = [];
		for(var i = 0 ;  i < this.props.checkinrecord.allperson.length ; i++){
			var oneperson = JSON.parse(this.props.checkinrecord.allperson[i]);
			allperson.push({
				key:i,
				name:oneperson.name,
				cardid:oneperson.cardid
			});
		}
		this.setState({allperson});
		if(location.search.substring(1)  == 2){
			var roominfo = [];
			for(var i = 0 ; i < this.props.checkinrecord.roominfo.length ; i++){
				roominfo.push({
					key:this.props.checkinrecord.roominfo[i].id,
					roomid:this.props.checkinrecord.roominfo[i].roomid,
					roomtype:this.props.checkinrecord.roominfo[i].roomtype
				});
			}
			this.setState({roominfo});
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		if(location.search.substring(1) == 1){
			return (
				<section id="checkindetail">
					<div className="title">入住详情</div>
					<Form layout={formLayout}>
						<FormItem label="入住房间号：" {...formItemLayout} >
							{this.props.checkinrecord.roomid}
						</FormItem>
						<FormItem label="入住房间类型：" {...formItemLayout} >
							{this.props.checkinrecord.roomtype}
						</FormItem>
						<FormItem label="入住人资料：" {...formItemLayout} >
						</FormItem>
						<Table columns={this.state.columnone} dataSource={this.state.allperson} bordered pagination={pagination}/>
						<FormItem label="每日花费：" {...formItemLayout} >
							{this.props.checkinrecord.casheveryday}
						</FormItem>
						<FormItem label="押金：" {...formItemLayout} >
							{this.props.checkinrecord.deposit}
						</FormItem>
						<FormItem label="剩余金额：" {...formItemLayout} >
							{this.props.checkinrecord.prepaid}
						</FormItem> 
						<FormItem label="付款方式：" {...formItemLayout} >
							{this.props.checkinrecord.cashtype}
						</FormItem>
						<FormItem label="当前状态：" {...formItemLayout} >
							{this.props.checkinrecord.state}
						</FormItem>
					</Form>
				</section>
				)
		}
		if(location.search.substring(1) == 2){
			return (
				<section id="checkindetail">
					<FormItem label="入住人资料：" {...formItemLayout} >
					</FormItem>
					<Table columns={this.state.columnone} dataSource={this.state.allperson} bordered pagination={pagination}/>
					<FormItem label="入住房间资料：" {...formItemLayout} >
					</FormItem>
					<Table columns={this.state.columntwo} dataSource={this.state.roominfo} bordered pagination={pagination}/>
					<FormItem label="每日花费：" {...formItemLayout} >
						{this.props.checkinrecord.casheveryday}
					</FormItem>
					<FormItem label="剩余金额：" {...formItemLayout} >
						{this.props.checkinrecord.prepaid}
					</FormItem>
					<FormItem label="付款方式：" {...formItemLayout} >
						{this.props.checkinrecord.cashtype}
					</FormItem>
					<FormItem label="当前状态：" {...formItemLayout} >
						{this.props.checkinrecord.state}
					</FormItem>
				</section>
				)
		}
	}
}

export default connect(
	(state)=>{
		return {
			checkinrecord:state.clickcheckin
		}
	},
	null
)(Checkindetail) ;