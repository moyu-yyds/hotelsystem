import React,{Component} from "react";
import {connect} from "react-redux";

import { Form, Button,Table } from 'antd';
const FormItem = Form.Item;

const pagination = {
	pageSize:6
}

class Checkout extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal',
			allperson:[],
			roominfo:[],
			columnone:[ 
				{
				title:'入住人姓名',
				dataIndex:'name'
				},
				{
				title:'入住人身份证号',
				dataIndex:'cardid'
				}
			],
			columntwo:[
				{
				title:'房间号',
				dataIndex:'roomid'
				},
				{
				title:'房间类型',
				dataIndex:'roomtype'
				}
			],
			cashmoney:0
		}
	}
	componentWillMount(){
		var cashmoney = this.props.clickcheckin.prepaid-this.props.clickcheckin.casheveryday;
		var allperson = [];
		for(var i = 0 ;  i < this.props.clickcheckin.allperson.length ; i++){
			var oneperson = JSON.parse(this.props.clickcheckin.allperson[i]);
			allperson.push({
				key:i,
				name:oneperson.name,
				cardid:oneperson.cardid
			});
		}
		this.setState({cashmoney,allperson});
		if(location.search.substring(1)  == 2){
			var roominfo = [];
			for(var i = 0 ; i < this.props.clickcheckin.roominfo.length ; i++){
				roominfo.push({
					key:this.props.clickcheckin.roominfo[i].id,
					roomid:this.props.clickcheckin.roominfo[i].roomid,
					roomtype:this.props.clickcheckin.roominfo[i].roomtype
				});
			}
			this.setState({roominfo});
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		} : null;
		const buttonItemLayout = formLayout === 'horizontal' ? {
		     wrapperCol: { span: 14, offset: 4 },
		} : null;
		if(location.search.substring(1) == 1 ){
			//个人用户结账
			return (
				<section id="checkout">
					<div className="title">个人用户结账</div>
					<Form layout={formLayout}>
						<FormItem label="入住房间号：" {...formItemLayout} >
							{this.props.clickcheckin.roomid}
						</FormItem>
						<FormItem label="入住房间类型：" {...formItemLayout} >
							{this.props.clickcheckin.roomtype}
						</FormItem>
						<FormItem label="入住人资料：" {...formItemLayout} >
						</FormItem>
						<Table columns={this.state.columnone} dataSource={this.state.allperson} bordered pagination={pagination}/>
						{
						this.state.cashmoney<0?
							<FormItem label="还应补付：" {...formItemLayout} >
								{-this.state.cashmoney}
							</FormItem>:
							<FormItem label="还应退还：" {...formItemLayout} >
								{this.state.cashmoney}
							</FormItem>
						}
						<FormItem label="剩余金额：" {...formItemLayout} >
							{this.props.clickcheckin.prepaid}
						</FormItem>
						<FormItem label="付款方式：" {...formItemLayout} >
							{this.props.clickcheckin.cashtype}
						</FormItem>
						<FormItem {...buttonItemLayout}>
							<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
						</FormItem>
					</Form>
				</section>
				)
		}
		if(location.search.substring(1) == 2){
			//团体用户结账
			return (
				<section id="checkout">
					<div className="title">团体用户结账</div>
					<Form>
						<FormItem label="入住人资料：" {...formItemLayout} >
						</FormItem>
						<Table columns={this.state.columnone} dataSource={this.state.allperson} bordered pagination={pagination}/>
						<FormItem label="入住房间资料：" {...formItemLayout} >
						</FormItem>
						<Table columns={this.state.columntwo} dataSource={this.state.roominfo} bordered pagination={pagination}/>
						{
						this.state.cashmoney<0?
							<FormItem label="还应补付：" {...formItemLayout} >
								{-this.state.cashmoney}
							</FormItem>:
							<FormItem label="还应退还：" {...formItemLayout} >
								{this.state.cashmoney}
							</FormItem>
						}
						<FormItem label="剩余金额：" {...formItemLayout} >
							{this.props.clickcheckin.prepaid}
						</FormItem>
						<FormItem label="付款方式：" {...formItemLayout} >
							{this.props.clickcheckin.cashtype}
						</FormItem>
						<FormItem {...buttonItemLayout}>
							<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
						</FormItem>
					</Form>
				</section>
				)
		}
	}
	submit(){
		if(location.search.substring(1) == 1){
			if(this.props.clickcheckin.cashtype == '非会员'){
				axios.post('/room/changeroomstate',{state:5,roomid:this.props.clickcheckin.roomid}).then(res=>{
					axios.post('/room/changepcheckin',{state:0,id:this.props.clickcheckin._id}).then(res=>{
						this.props.getallroom();
						alert('退房成功！');
					});
				});
			}
			if(this.props.clickcheckin.cashtype == '会员'){
				axios.post('/room/changeroomstate',{state:5,roomid:this.props.clickcheckin.roomid}).then(res=>{
					axios.post('/room/changepcheckin',{state:0,id:this.props.clickcheckin._id}).then(resone=>{
						axios.post('/resident/deduction',{
							state:1,
							name:this.props.clickcheckin.firstname,
							cardid:this.props.clickcheckin.firstcardid,
							moneyeveryday:this.props.clickcheckin.casheveryday,
							money:this.state.cashmoney
						}).then(restwo=>{
							this.props.getallroom();
							alert('退房成功！');
						});
					});
				});
			}
		}
		if(location.search.substring(1) == 2){
			if(this.props.clickcheckin.cashtype == '非会员'){
				axios.post('/room/changeroomstate',{state:6,len:this.props.clickcheckin.roominfo.length,roominfo:this.props.clickcheckin.roominfo}).then(res=>{
					axios.post('/room/changetcheckin',{state:0,id:this.props.clickcheckin._id}).then(resone=>{
						this.props.getallroom();
						alert('退房成功！');
					})
				});
			}
			if(this.props.clickcheckin.cashtype == '会员'){
				axios.post('/room/changeroomstate',{state:6,len:this.props.clickcheckin.roominfo.length,roominfo:this.props.clickcheckin.roominfo}).then(res=>{
					axios.post('/room/changetcheckin',{state:0,id:this.props.clickcheckin._id}).then(resone=>{
						axios.post('/resident/deduction',{
							state:2,
							name:this.props.clickcheckin.firstname,
							cardid:this.props.clickcheckin.firstcardid,
							moneyeveryday:this.props.clickcheckin.casheveryday,
							money:this.state.cashmoney
						}).then(restwo=>{
							this.props.getallroom();
							alert('退房成功！');
						});
					})
				});
			}
		}
	}
}

export default connect(
	(state)=>{
		return {
			clickcheckin:state.clickcheckin
		}
	},
	{
		getallroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		}
	}
)(Checkout);