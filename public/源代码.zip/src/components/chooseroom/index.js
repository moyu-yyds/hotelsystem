import React,{Component} from "react";
import {connect} from "react-redux";

import {Table,Button} from 'antd';

const pagination = {
	pageSize:6
}
 
class Chooseroom extends Component{
	constructor(){
		super();
		this.state = {
			choose:[],
			type:location.search.substring(1),
			columns : [
				{
				title: '房间号',
			  	dataIndex: 'roomid',
				}, 
				{
			 	title: '房间类型',
			  	dataIndex: 'roomtype',
				},
			 	{
			  	title: '房间状态',
			 	dataIndex: 'state',
				},
				{
				title:'操作',
				dataIndex:'choose',
				className:'operation',
				render:(text,record)=><span onClick={this.choose.bind(this,record.roominfo)}>{text}</span>
				}
			],
			restroom:[]
		}
	}
	componentWillMount(){
		var restroom = [];
		axios.get('/room/restroom').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				restroom.push({
					key:res.data[i]._id,
					roomid:res.data[i].roomid,
					roomtype:res.data[i].roomtype,
					state:res.data[i].state,
					choose:'选择该房间',
					roominfo:res.data[i]
				});
			}	
			this.setState({restroom});
		});
		
	}
	render(){
		return (
			<section id="chooseroom">	
				<Table columns={this.state.columns} dataSource={this.state.restroom} bordered pagination={pagination}/>				
				<Button type="primary" onClick={this.jump.bind(this)}>提交</Button>
			</section>
			)
	}
	choose(room){
		if(this.state.choose.length == 0){
			//数组的push方法返回值为数组长度，应该先用push方法改变数组，再改变状态
			this.state.choose.push(room);
			this.setState({choose:this.state.choose});
		}
		else{
			for(var i = 0 ; i < this.state.choose.length; i ++){
			 	if(room._id == this.state.choose[i]._id){
					alert('已选择该房间，不能重复选择！');
					break;
			 	}
			 }
			 if(i == this.state.choose.length){
			 	this.state.choose.push(room);                              
			 	this.setState({choose:this.state.choose});
			 }
		}
	}
	jump(){
		this.props.getchosenroom(this.state.choose);
		//预定选择房间
		if(this.state.type == 11){
			this.props.history.push(`/home/preservation?${this.state.type}`);
		}
		if(this.state.type == 22){
			this.props.history.push(`/home/treservation?${this.state.type}`);
		}
		//入住选择房间
		if(this.state.type == 33 || this.state.type == 44){
			this.props.history.push(`/home/checkinbaseinfo?${this.state.type}`);
		}	
	}
}

export default connect(
	(state)=>{
		return {
			restroom:state.restroom
		}
	},
	{
		getchosenroom(chosenroom){
			return {
				type:'chosenroom',
				payload:chosenroom
			}
		}
	}
	)(Chooseroom);