import React,{Component} from 'react';
import {connect} from 'react-redux';
 
import { Form,Button } from 'antd';
const FormItem = Form.Item;

class Clean extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	componentWillMount(){
		this.props.getrestroom();
		this.props.getrestcleanperson();
		this.props.getallcleanperson();
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 4 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="maintenance">
				<div className="title">清洁登记</div>
				<Form layout={formLayout}>
					<FormItem label="房间信息" {...formItemLayout} >
						<select ref="roominfo">
						          {
						          	this.props.restroom.map((item)=>
						          		<option value ={JSON.stringify(item)} key={item._id}>{item.roomid} {item.roomtype}</option>
						         	 	)
						          	}
						</select>
					</FormItem>
					<FormItem label="清洁人员信息" {...formItemLayout} >
						<select ref="personinfo">
						          {
						          	this.props.restcleanperson.map((item)=>
						          		<option value ={JSON.stringify(item)} key={item._id}>{item.name}</option>
						          		)
						          	}
						</select>
					</FormItem>
					<FormItem {...buttonItemLayout}>
					 	<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
					</FormItem>
				</Form>
			</section>
			)
	}
	submit(){
		var room = this.refs.roominfo.value;
		var person = this.refs.personinfo.value;
		axios.post('/clean/cleantable',{room,person}).then(res=>{
			axios.post('/room/changeroomstate',{state:2,data:room}).then(res=>{
				this.props.updateroom();
				axios.post('/clean/changepersonstate',{state:0,person:person,allperson:this.props.allcleanperson}).then(res=>{
					this.props.getallcleanperson();
					alert('提交成功！');
				});
			});
		});
		
		
	}
}

export default connect(
	(state)=>{
		return {
			restroom:state.restroom,
			restcleanperson:state.restcleanperson,
			allcleanperson:state.allcleanperson
		}
	},
	{
		getrestroom(){
			return axios.get('/room/restroom').then(res=>{
				return {
					type:'restroom',
					payload:res.data
				}
			});
		},
		getrestcleanperson(){
			return axios.get('/clean/restperson').then(res=>{
				return {
					type:'restcleanperson',
					payload:res.data
				}
			});
		},
		updateroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		},
		getallcleanperson(){
			return axios.get('/clean/allperson').then(res=>{
				return {
					type:'allcleanperson',
					payload:res.data
				}
			});
		}
	})(Clean);