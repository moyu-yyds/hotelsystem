import React,{Component} from "react";
import {connect} from "react-redux";

import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
}
 
const pagination = {
	pageSize:6
}

class Cleanmanage extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '清洁人员姓名',
			  	dataIndex: 'name',
				}, 
				{
			 	title: '清洁房间号',
			  	dataIndex: 'roomid',
				},
				{
			   	title:"清洁状态",
			   	dataIndex:'state',
			  	 },
			  	 {
			  	 title:"操作1",
			  	 dataIndex:'end',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.cancel.bind(this,record)}>{text}</span>
			  	 }
			],
			clean : [],
			inclean : [],
			completeclean : []
		}
	}
	componentWillMount(){
		var clean = [];
		var inclean = [];
		var completeclean = [];
		axios.get('/clean/allclean').then(res=>{
		 	for(var i = 0 ; i < res.data.length ; i++){
		 		clean.push({
		 			key:res.data[i]._id,
		 			name:res.data[i].cleanperson,
		 			roomid:res.data[i].roomid,
		 			state:res.data[i].state,
		 			end:'结束清洁'
		 		});	
		 	}
		 	for(var i = 0 ; i < clean.length ; i++){
		 		if(clean[i].state == '清洁中'){
		 			inclean.push(clean[i]);
		 		}
		 		if(clean[i].state == '已完成'){
		 			completeclean.push(clean[i]);
		 		}
		 	}
		 	this.setState({clean,inclean,completeclean});
		});
	}
	render(){
		return (
			<Tabs defaultActiveKey="1" onChange={callback}>
				<TabPane tab="所有清洁记录" key="1">
					<Table columns={this.state.columns} dataSource={this.state.clean} bordered pagination={pagination}/>
				</TabPane>
				<TabPane tab="清洁中记录" key="2">
					<Table columns={this.state.columns} dataSource={this.state.inclean} bordered pagination={pagination}/>
				</TabPane>
				<TabPane tab="已完成清洁记录" key="3">
					<Table columns={this.state.columns} dataSource={this.state.completeclean} bordered pagination={pagination}/>
				</TabPane>
			</Tabs>
			)
	}
	cancel(record){
		if(record.state == "清洁中"){
			axios.post('/clean/changeclean',{id:record.key}).then(resone=>{
				//改变state
				var clean = [];
				var inclean = [];
				var completeclean = [];
				axios.get('/clean/allclean').then(res=>{
					for(var i = 0 ; i < res.data.length ; i++){
					 	clean.push({
					 		key:res.data[i]._id,
					 		name:res.data[i].cleanperson,
					 		roomid:res.data[i].roomid,
					 		state:res.data[i].state,
					 		end:'结束清洁'
					 	});	
					} 
					for(var i = 0 ; i < clean.length ; i++){
						if(clean[i].state == '清洁中'){
						 	inclean.push(clean[i]);
						}
						if(clean[i].state == '已完成'){
						 	completeclean.push(clean[i]);
						 }
					}
					this.setState({clean,inclean,completeclean});
					axios.post('/clean/changepersonstate',{state:1,name:record.name}).then(resthree=>{
						axios.post('/room/changeroomstate',{state:5,roomid:record.roomid}).then(resfour=>{
							this.props.getallroom();
							alert('已结束清洁！');
						});
					});
				});	
			});
		}else{
			alert('该状态不可再发生改变！');
		}
	}
}

export default connect(
	null,
	{
		getallroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		}
	}
)(Cleanmanage);