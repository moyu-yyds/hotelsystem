import React,{Component} from "react";
import {connect} from "react-redux";

import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
}
  
const pagination = {
	pageSize:6
}

class Dealbaddebt extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '入住代表名',
			  	dataIndex: 'name'
				}, 
				{
			 	title: '入住代表身份证号',
			  	dataIndex: 'cardid'
				},
				{
			 	title: '类型',
			  	dataIndex: 'type'
				},
				{
				title: '付款方式',
			 	dataIndex: 'cashtype'
				},
				{
				title:'操作1',
				dataIndex:'view',
				className:'operation',
				render:(text,record)=><span onClick={this.view.bind(this,record.allinfo,record.type)}>{text}</span>
				},
				{ 
				title:'操作2',
				dataIndex:'resolve',
				className:'operation',
				render:(text,record)=><span onClick={this.resolve.bind(this,record.allinfo,record.type)}>{text}</span>
				}
			],
			allbaddebt:[],
			pbaddebt:[],
			tbaddebt:[]
		}
	}
	componentWillMount(){
		var allbaddebt = [];
		var pbaddebt = [];
		var tbaddebt = [];
		axios.get('/room/badpcheckinroom').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				pbaddebt.push({
					key:res.data[i]._id,
					name:res.data[i].firstname,
					cardid:res.data[i].firstcardid,
					type:'个人',
					cashtype:res.data[i].cashtype,
					allinfo:res.data[i],
					view:'查看详情',
					resolve:'坏账处理'
				});
				allbaddebt.push(pbaddebt[i]);
			}
			axios.get('/room/badtcheckinroom').then(resone=>{
				for(var i = 0 ; i < resone.data.length ; i++){
					tbaddebt.push({
						key:resone.data[i]._id,
						name:resone.data[i].firstname,
						cardid:resone.data[i].firstcardid,
						type:'团体',
						cashtype:resone.data[i].cashtype,
						allinfo:resone.data[i],
						view:'查看详情',
						resolve:'坏账处理'
					});
					allbaddebt.push(tbaddebt[i]);
				}
			});
			this.setState({allbaddebt,pbaddebt,tbaddebt});
		});
	}
	render(){
		return (
			<section id="dealbaddebt">
				<Tabs defaultActiveKey="1" onChange={callback}>
					<TabPane tab="所有坏账" key="1">
						<Table columns={this.state.columns} dataSource={this.state.allbaddebt} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="个人坏账" key="2">
						<Table columns={this.state.columns} dataSource={this.state.pbaddebt} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="团体坏账" key="3">
						<Table columns={this.state.columns} dataSource={this.state.tbaddebt} bordered pagination={pagination}/>
					</TabPane>
				</Tabs>
			</section>
			)
	}
	view(data,type){
		if(type == '个人'){
			this.props.getclickcheckin(data);
			this.props.history.push('/home/checkindetail?1');
		}
		if(type == '团体'){
			this.props.getclickcheckin(data);
			this.props.history.push('/home/checkindetail?2');
		}
	}
	resolve(data,type){
		if(type == '个人'){
			this.props.getclickcheckin(data);
			this.props.history.push('/home/topup?2');
		}
		if(type == '团体'){
			this.props.getclickcheckin(data);
			this.props.history.push('/home/topup?3');
		}
	}
} 

export default connect(
	null,
	{
		getclickcheckin(data){
			return {
				type:'clickcheckin',
				payload:data
			}
		}	
	}
)(Dealbaddebt);