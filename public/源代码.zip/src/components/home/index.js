//系统的主页面(首页)
import React,{Component} from "react";

import {NavLink} from "react-router-dom";

import {connect} from "react-redux";

import "./index.scss";
 
import { Layout, Menu, Breadcrumb, Icon } from 'antd';
const { SubMenu } = Menu;
const { Header, Content, Sider } = Layout;

class Home extends Component{
	componentWillMount(){
		this.props.getroomprice();
		this.props.getallroom();
		this.props.getallresident();
	}
	render(){
		return (
			<section id="home">
				<Layout>
				     	<Header className="header">
				     		{
					  		//系统的头部布局
						 }
						 <div className="home-title">酒店管理系统</div>
						 <div className="home-username">
						 	你好，
						 	<span className="home-loginuser">
						 		{this.props.userinfo.username}
						 	</span>，
						 	欢迎登陆&nbsp;&nbsp;&nbsp;
						 	<span className="home-logout"><NavLink to='/login'>注销</NavLink></span>
					 	</div>
					</Header>
					<Layout>
						{
						//左方的导航栏
						}
						<Sider width={200} style={{ background: '#fff' }}>
					 		<Menu
					        		mode="inline"
					          	style={{ height: '100%' }}
					          	>
						          	<SubMenu key="sub1" title={<span>员工管理</span>}>
						          		<Menu.Item key="1"><span><NavLink to='/home/register'>员工注册</NavLink></span></Menu.Item>
						          		<Menu.Item key="2"><span><NavLink to='/home/usermanagement'>员工信息管理</NavLink></span></Menu.Item>
						          		<Menu.Item key="3"><span><NavLink to='/home/changepassword'>密码修改</NavLink></span></Menu.Item>
						          	</SubMenu>
						          	<SubMenu key="sub2" title={<span><NavLink to='/home/roomprice'>房间价格</NavLink></span>}></SubMenu>
						          	<SubMenu key="sub3" title={<span><NavLink to='/home/room'>房间状态</NavLink></span>}></SubMenu>
						          	<SubMenu key="sub4" title={<span>房间预定</span>}>
					           			<Menu.Item key="4"><span><NavLink to='/home/preservation?1'>个人预定</NavLink></span></Menu.Item>
						           		<Menu.Item key="5"><span><NavLink to='/home/treservation?1'>团体预定</NavLink></span></Menu.Item>
						           		<Menu.Item key="6"><span><NavLink to='/home/resermanage'>预定管理</NavLink></span></Menu.Item>
						         		</SubMenu>
						         		<SubMenu key="sub5" title={<span>前台接待</span>}>
						           		<Menu.Item key="7"><span><NavLink to='/home/checkin'>入住登记</NavLink></span></Menu.Item>
						           		<Menu.Item key="8"><span><NavLink to='/home/pcheckout'>个人结算</NavLink></span></Menu.Item>
						           		<Menu.Item key="9"><span><NavLink to='/home/tcheckout'>团体结算</NavLink></span></Menu.Item>
						           		<Menu.Item key="10"><span><NavLink to='/home/pchrecord'>个人入住记录</NavLink></span></Menu.Item>
						           		<Menu.Item key="11"><span><NavLink to='/home/tchrecord'>团体入住记录</NavLink></span></Menu.Item>
						           		<Menu.Item key="12"><span><NavLink to='/home/owedebt'>收费提示</NavLink></span></Menu.Item>
						           		<Menu.Item key="13"><span><NavLink to='/home/dealbaddebt'>坏账处理</NavLink></span></Menu.Item>
					        			</SubMenu>
						         		<SubMenu key="sub6" title={<span>维修清洁记录</span>}>
						           		<Menu.Item key="14"><span><NavLink to='/home/maintenance'>客房维修登记</NavLink></span></Menu.Item>
						           		<Menu.Item key="15"><span><NavLink to='/home/clean'>客房清洁登记</NavLink></span></Menu.Item>
						           		<Menu.Item key="16"><span><NavLink to='/home/maintenmanage'>客房维修记录</NavLink></span></Menu.Item>
						           		<Menu.Item key="17"><span><NavLink to='/home/cleanmanage'>客房清洁记录</NavLink></span></Menu.Item>
						         		</SubMenu>
						         		<SubMenu key="sub7" title={<span>会员记录</span>}>
						         			<Menu.Item key="18"><span><NavLink to='/home/memregister'>会员登记</NavLink></span></Menu.Item>
						           		<Menu.Item key="19"><span><NavLink to='/home/vipmanagement'>会员管理</NavLink></span></Menu.Item>
						         		</SubMenu>			
					       	    	</Menu>
						 </Sider>
					     	{
					     	//右方的内容区
					     	}
					     	<div className="home-content">
					     		{this.props.children}
					     	</div>
					</Layout>
				</Layout>
			</section>
		)
	}
}

export default connect(
	(state) => {
		return {
			userinfo:state.userinfo,
			personvip:state.allpersonvip
		}
	},
	{
		getroomprice(){
			return axios.get('/room/roomprice').then(res=>{
				return {
					type:'roomprice',
					payload:res.data
				}
			});
		},
		getallroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		},
		getallresident(){
			return axios.get('/resident/allresident').then(res=>{
				return {
					type:'allresident',
					payload:res.data
				}
			});
		},
	}
)(Home) ;