import React,{Component} from "react";
import {connect} from "react-redux";

import "./index.scss";

class Login extends Component{
	constructor(){
		super();
		this.state={
			remindphone : "",
			remindpassword:""
		}
	}
	render(){
		return (
			<section id="login">
				<div className="login-form">
					<div className="login-phonenumber">
						<input type="text" placeholder="请输入手机号码" ref="phonenumber" onChange={this.phonenumber.bind(this)}/>
						<aside className="login-remindphone" className="login-remindmessage">{this.state.remindphone}</aside>
					</div>
					<div className="login-password">
						<input type="password" placeholder="请输入密码" ref="password" onChange={this.password.bind(this)}/>
						<aside className="login-remindpassword" className="login-remindmessage">{this.state.remindpassword}</aside>
					</div>
					<div className="login-submit">
						<input type="button" value="登录" onClick={this.loginsubmit.bind(this)} />
					</div>
				</div>
			</section>
			)
	}
	phonenumber(){
		var phonenumber = this.refs.phonenumber.value;
		if(phonenumber == ""){
			this.setState({remindphone:"手机号码不能为空！"});
		}
		else{
			this.setState({remindphone:""});
		}
	}
	password(){
		var password = this.refs.password.value;
		if(password == ""){
			this.setState({remindpassword:"密码不能为空！"});
		}
		else{
			this.setState({remindpassword:""});
		}
	}
	loginsubmit(){
		//先判断是否有信息未填写
		var phonenumber = this.refs.phonenumber.value ;
		var password = this.refs.password.value ;
		if(phonenumber ==  "" || password == ""){
			this.refs.phonenumber.value =  "" ;
			this.refs.password.value = "" ;
			alert("手机号码或者密码未填写！");
		}else{
			var data = JSON.stringify({"phonenumber":phonenumber,"password":password});
			axios.post('/user/validation',{data}).then(res=>{
				if(res.data == 0){
					this.refs.phonenumber.value =  "" ;
					this.refs.password.value = "" ;
					alert('手机号码或者密码有错误！');
				}else{
					this.props.saveuserinfo(res.data);
					this.props.history.push('/home/roomprice');
				}
			});	
		}
	}
}

export default connect(
	null,
	{
		saveuserinfo(userinfo){
			return {
				type:"userinfo",
				payload:userinfo
			}
		}
	})(Login);