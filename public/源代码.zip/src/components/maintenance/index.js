import React,{Component} from 'react';
import {connect} from 'react-redux';

import { Form, Button } from 'antd';
const FormItem = Form.Item;

class Maintenance extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	componentWillMount(){
		this.props.getrestroom();
		this.props.getrestmaintenperson();
		this.props.getallmaintenperson();
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 4 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="maintenance">
				<div className="title">维修登记</div>
				<Form layout={formLayout}>
			         		<FormItem label="房间信息" {...formItemLayout} >
			          			<select ref="roominfo">
			          				{
			          				this.props.restroom.map((item)=>
			          					<option value ={JSON.stringify(item)} key={item._id}>{item.roomid} {item.roomtype}</option>
			          					)
			          				}
			          			</select>
		          			</FormItem>
			          		<FormItem label="维修工人信息" {...formItemLayout} >
			          			<select ref="personinfo">
			          				{
			          				this.props.restmaintenperson.map((item)=>
			          					 <option value ={JSON.stringify(item)} key={item._id}>{item.name}</option>
			          					)
			          				}
			          			</select>
			          		</FormItem>
			          		<FormItem label="维修物品登记" {...formItemLayout} >
			          		<textarea type="text" placeholder="需要维修的物品" ref="items"></textarea>
			          		</FormItem>
			          		<FormItem {...buttonItemLayout}>
			           		<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
			          		</FormItem>
			        </Form>
			</section>
			)
	}
	submit(){
		var room = this.refs.roominfo.value;
		var person = this.refs.personinfo.value;
		var items = this.refs.items.value;
		if(items){
			axios.post('/maintenance/maintenancetable',{room,person,items}).then(resone=>{
				axios.post('/room/changeroomstate',{state:1,data:room}).then(restwo=>{
					this.props.updateroom();
					axios.post('/maintenance/changepersonstate',{state:0,person:person,allperson:this.props.allmaintenperson}).then(resthree=>{
						this.props.getallmaintenperson();
						alert('提交成功！');
					});
				});
			});
		}else{
			alert('请填写维修物品！');
		}
	}
}

export default connect(
	(state)=>{
		return {
			restroom:state.restroom,
			restmaintenperson:state.restmaintenperson,
			allmaintenperson:state.allmaintenperson
		}
	},
	{
		getrestroom(){
			return axios.get('/room/restroom').then(res=>{
				return {
					type:'restroom',
					payload:res.data
				}
			});
		},
		getrestmaintenperson(){
			return axios.get('/maintenance/restperson').then(res=>{
				return {
					type:'restmaintenperson',
					payload:res.data
				}
			});
		},
		updateroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		},
		getallmaintenperson(){
			return axios.get('/maintenance/allperson').then(res=>{
				return {
					type:'allmaintenperson',
					payload:res.data
				}
			});
		}
	})(Maintenance);