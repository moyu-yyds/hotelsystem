import React,{Component} from "react";
import {connect} from "react-redux";

import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
}
 
const pagination = {
	pageSize:6
}

class Maintenmanage extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '维修工姓名',
			  	dataIndex: 'name',
				}, 
				{
			 	title: '维修房间号',
			  	dataIndex: 'roomid',
				},
			 	{
			  	title: '维修物品',
			 	dataIndex: 'items',
				},
				{
			   	title:"维修状态",
			   	dataIndex:'state',
			  	 },
			  	 {
			  	 title:"操作1",
			  	 dataIndex:'end',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.cancel.bind(this,record)}>{text}</span>
			  	 }
			],
			maintenance : [],
			inmaintenance : [],
			completemaintenance : []
		}
	}
	componentWillMount(){
		var maintenance = [];
		var inmaintenance = [];
		var completemaintenance = [];
		axios.get('/maintenance/allmaintenance').then(res=>{
		 	for(var i = 0 ; i < res.data.length ; i++){
		 		maintenance.push({
		 			key:res.data[i]._id,
		 			name:res.data[i].maintenperson,
		 			roomid:res.data[i].roomid,
		 			items:res.data[i].maintenitems,
		 			state:res.data[i].state,
					end:'结束维修',
		 		});
		 	}
		 	for(var i = 0 ; i < maintenance.length ; i++){
		 		if(maintenance.state == '维修中'){
		 			inmaintenance.push(maintenance[i]);
		 		}
		 		if(maintenance.state == '已完成'){
		 			completemaintenance.push(maintenance[i]);
		 		}
		 	}
		 	this.setState({maintenance,inmaintenance,completemaintenance});	
		});
	}
	render(){
		return (
			<Tabs defaultActiveKey="1" onChange={callback}>
				<TabPane tab="所有维修记录" key="1">
					<Table columns={this.state.columns} dataSource={this.state.maintenance} bordered pagination={pagination}/>
				</TabPane>
				<TabPane tab="维修中记录" key="2">
					<Table columns={this.state.columns} dataSource={this.state.inmaintenance} bordered pagination={pagination}/>
				</TabPane>
				<TabPane tab="已完成维修记录" key="3">
					<Table columns={this.state.columns} dataSource={this.state.completemaintenance} bordered pagination={pagination}/>
				</TabPane>
			</Tabs>
			)
	}
	cancel(record){
		//先改变维修记录，再改变维修人员状态，最后改变房间状态
		if(record.state == "维修中"){
			axios.post('/maintenance/changemaintenance',{id:record.key}).then(resone=>{
				//改变state
				var maintenance = [];
				var inmaintenance = [];
				var completemaintenance = [];
				axios.get('/maintenance/allmaintenance').then(res=>{
				 	for(var i = 0 ; i < res.data.length ; i++){
				 		maintenance.push({
				 			key:res.data[i]._id,
				 			name:res.data[i].maintenperson,
				 			roomid:res.data[i].roomid,
				 			items:res.data[i].maintenitems,
				 			state:res.data[i].state,
							end:'结束维修',
				 		});
				 	}
				 	for(var i = 0 ; i < maintenance.length ; i++){
				 		if(maintenance.state == '维修中'){
				 			inmaintenance.push(maintenance[i]);
				 		}
				 		if(maintenance.state == '已完成'){
				 			completemaintenance.push(maintenance[i]);
				 		}
				 	}
				 	this.setState({maintenance,inmaintenance,completemaintenance});	
				 	axios.post('/maintenance/changepersonstate',{state:1,name:record.name}).then(resthree=>{
				 		axios.post('/room/changeroomstate',{state:5,roomid:record.roomid}).then(resfour=>{
				 			this.props.getallroom();
				 			alert('已结束维修！');
				 		});
				 	});
				});	
			});
		}else{
			alert('该状态不可再发生改变！');
		}
	}
}

export default connect(
	null,
	{
		getallroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		}
	}
)(Maintenmanage);