import React,{Component} from 'react';
import {connect} from 'react-redux';

import { Form, Button } from 'antd';
const FormItem = Form.Item;

class Memreginfo extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal',
			type:'个人会员注册'
		}
	}
	componentWillMount(){
		if(location.search.substring(1) == 2 || location.search.substring(1) == 4){
			this.setState({type:'团体会员注册'});
		}
		this.props.getresident();
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id='memreginfo'>
				<div className="title">{this.state.type}</div>
				<Form layout={formLayout}>
					<FormItem label="姓名：" {...formItemLayout} >
						{this.props.memregbaseinfo.name}
					</FormItem>
					<FormItem label="身份证号码：" {...formItemLayout} >
						{this.props.memregbaseinfo.cardid}
					</FormItem>
					<FormItem label="初始充值（至少500）：" {...formItemLayout} >
						<input type='number' ref="money" min='500'  step='100'/>
					</FormItem>
					<FormItem {...buttonItemLayout}>
						<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
					</FormItem>
				</Form>
			</section>
			)
	}
	submit(){
		if(parseInt(this.refs.money.value) >= 500){
			if(location.search.substring(1) == 1){
				//个人首次注册
				axios.post('/resident/vip',{
					flag:1,
					name:this.props.memregbaseinfo.name,
					cardid:this.props.memregbaseinfo.cardid,
					money:this.refs.money.value
				}).then(res=>{
					this.props.getallpersonvip();
					alert('会员注册成功！');
				});
			}
			if(location.search.substring(1) == 2){
				//团队首次注册
				axios.post('/resident/vip',{
					flag:2,
					name:this.props.memregbaseinfo.name,
					cardid:this.props.memregbaseinfo.cardid,
					money:this.refs.money.value
				}).then(res=>{
					this.props.getallteamvip();
					alert('会员注册成功！');
				});
			}
			if(location.search.substring(1) == 3){
				//过往住户注册个人会员
				axios.post('/resident/vip',{
					flag:3,
					id:this.props.memregbaseinfo.id,
					name:this.props.memregbaseinfo.name,
					cardid:this.props.memregbaseinfo.cardid,
					state:this.props.memregbaseinfo.state,
					money:this.refs.money.value
				}).then(res=>{
					this.props.getallteamvip();
					alert('会员注册成功！');
				});
			}
			if(location.search.substring(1) == 4){
				//过往住户注册团体会员
				axios.post('/resident/vip',{
					flag:4,
					id:this.props.memregbaseinfo.id,
					name:this.props.memregbaseinfo.name,
					cardid:this.props.memregbaseinfo.cardid,
					state:this.props.memregbaseinfo.state,
					money:this.refs.money.value
				}).then(res=>{
					this.props.getallteamvip();
					alert('会员注册成功！');
				});
			}
		}else{
			alert('预存款项不足500！');
		}
	}
}

export default connect(
	(state)=>{
		return {
			allresident:state.allresident,
			memregbaseinfo:state.memregbaseinfo
		}
	},
	{
		getresident(){
			return axios.get('/resident/allresident').then(res=>{
				return {
					type:'allresident',
					payload:res.data
				}
			});
		},
		getallpersonvip(){
			return axios.get('/resident/allpersonvip').then(res=>{
				return {
					type:'allpersonvip',
					payload:res.data
				}
			});
		},
		getallteamvip(){
			return axios.get('/resident/allteamvip').then(res=>{
				return {
					type:'allteamvip',
					payload:res.data
				}
			});
		}
	}
	)(Memreginfo);