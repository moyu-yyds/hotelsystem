import React,{Component} from "react";
import {connect} from 'react-redux';
 
import { Form, Button } from 'antd';
const FormItem = Form.Item;

class Memregister extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="memregister">
				<div className="title">基本信息填写</div>
				<Form layout={formLayout}>
					<FormItem label="办理者姓名：" {...formItemLayout} >
						<input type="text" ref='name' placeholder="请输入姓名"/>
					</FormItem>
					<FormItem label="办理者身份证号码：" {...formItemLayout} >
						<input type="text" ref='cardid' placeholder="请输入身份证号码"/>
					</FormItem>
					<FormItem label="办理业务：" {...formItemLayout} >
						<select ref='business'>
							<option value='个人会员'>个人会员</option>
							<option value='团体会员'>团体会员</option>
						</select>
					</FormItem>
					<FormItem {...buttonItemLayout}>
						<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
					</FormItem>
				</Form>
			</section>
			)
	}
	submit(){
		var business = this.refs.business.value;
		var name = this.refs.name.value;
		var cardid = this.refs.cardid.value;
		if(name && cardid){
			axios.post('/resident/searchsb',{name,cardid}).then(res=>{
				var result = res.data;
				if(result.length == 0){
					//这是从未入住过的住户
					if(business == '个人会员'){
						this.props.getmemregbaseinfo({name,cardid});
						this.props.history.push('/home/memreginfo?1');
					}
					if(business == '团体会员'){
						this.props.getmemregbaseinfo({name,cardid});
						this.props.history.push('/home/memreginfo?2');
					}
				}else{
					//有入住记录的住户
					for(var i = 0 ; i < result[0].state.length ; i++){
						if(result[0].state[i] == business){
							alert('不能重复办理业务！');
							break;
						}
					}
					if(i == result[0].state.length){
						if(business == '个人会员'){
							this.props.getmemregbaseinfo({id:result[0]._id,name,cardid,state:result[0].state});
							this.props.history.push('/home/memreginfo?3');
						}
						if(business == '团体会员'){
							this.props.getmemregbaseinfo({id:result[0]._id,name,cardid,state:result[0].state});
							this.props.history.push('/home/memreginfo?4');
						}
					}
				}
			});
		}else{
			alert('请将信息填写完整！');
		}
	}
}

export default connect(
	(state)=>{
		return {
			allresident:state.allresident
		}
	},
	{
		getmemregbaseinfo(data){
			return {
				type:'memregbaseinfo',
				payload:data
			}
		}
	}
	)(Memregister) ;