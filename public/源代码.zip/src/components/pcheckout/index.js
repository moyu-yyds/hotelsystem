import React,{Component} from "react";
import {connect} from "react-redux";

import { Table } from 'antd';
  
const pagination = { 
	pageSize:6
}

class Pcheckout extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '入住代表名',
			  	dataIndex: 'name'
				}, 
				{
			 	title: '入住代表身份证号',
			  	dataIndex: 'cardid'
				},
				{
			 	title: '房间号',
			  	dataIndex: 'roomid'
				},
				{
			 	title: '每日花费',
			  	dataIndex: 'casheveryday'
				},
				{
			 	title: '押金',
			  	dataIndex: 'deposit'
				},
				{
			 	title: '剩余金额',
			  	dataIndex: 'prepaid'
				},
				{
			 	title: '付款方式',
			  	dataIndex: 'cashtype'
				},
				{
			 	title: '当前状态',
			  	dataIndex: 'state'
				},
			  	{ 
			  	 title:"操作1",
			  	 dataIndex:'renewal',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.renewal.bind(this,record.allinfo)}>{text}</span>
			  	},
			  	{ 
			  	 title:"操作2",
			  	 dataIndex:'checkout',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.checkout.bind(this,record.allinfo)}>{text}</span>
			  	}
			],
			pcheckout:[]
		}
	} 
	componentWillMount(){
		var pcheckout = [];
		axios.get('/room/allpcheckinroom').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
					pcheckout.push({
						key:res.data[i]._id,
						name:res.data[i].firstname,
						cardid:res.data[i].firstcardid,
						roomid:res.data[i].roomid,
						casheveryday:res.data[i].casheveryday,
						deposit:res.data[i].deposit,
						prepaid:res.data[i].prepaid,
						cashtype:res.data[i].cashtype,
						state:res.data[i].state,
						allinfo:res.data[i],
						renewal:'续租',
						checkout:'退房'
					});
				}
			}
			this.setState({pcheckout});
		});
	}
	render(){
		return (
			<section id="pcheckout">
				<div className="operation oneday" onClick={this.oneday.bind(this)}>一天时间过去了...</div>
				<Table columns={this.state.columns} dataSource={this.state.pcheckout} bordered pagination={pagination}/>
			</section>
			)
	} 
	renewal(data){
		this.props.getclickcheckin(data);
		this.props.history.push('/home/topup?2');
	}
	checkout(data){
		this.props.getclickcheckin(data);
		this.props.history.push('/home/checkout?1');
	}
	oneday(){
		var pcheckout = this.state.pcheckout;
		var len = pcheckout.length ;
		var that = this;
		function callback(num){
			var money = pcheckout[num].prepaid - pcheckout[num].casheveryday;
			if(pcheckout[num].cashtype == '非会员' && money >= -5000){
				axios.post('/room/changepcheckin',{state:1,money,id:pcheckout[num].key}).then(res=>{	
					num = num + 1 ; 
					if(num < len){
						callback(num);
					}
					if(num == len){
						var pcheckout = [];
						axios.get('/room/allpcheckinroom').then(res=>{
							for(var i = 0 ; i < res.data.length ; i++){
								if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
									pcheckout.push({
										key:res.data[i]._id,
										name:res.data[i].firstname,
										cardid:res.data[i].firstcardid,
										roomid:res.data[i].roomid,
										casheveryday:res.data[i].casheveryday,
										deposit:res.data[i].deposit,
										prepaid:res.data[i].prepaid,
										cashtype:res.data[i].cashtype,
										state:res.data[i].state,
										allinfo:res.data[i],
										renewal:'续租',
										checkout:'退房'
									});
								}
							}
							that.setState({pcheckout});
							alert('更新完毕！');
						});
					}
				});
			}
			if(pcheckout[num].cashtype == '非会员' && money < -5000){
				axios.post('/room/changepcheckin',{state:1,money,id:pcheckout[num].key}).then(res=>{
					axios.post('/room/changeroomstate',{state:5,roomid:pcheckout[num].roomid}).then(resone=>{
						num = num + 1 ; 
						if(num <len){
							callback(num);
						}
						if(num == len){
							var pcheckout = [];
							axios.get('/room/allpcheckinroom').then(res=>{
								for(var i = 0 ; i < res.data.length ; i++){
									if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
										pcheckout.push({
											key:res.data[i]._id,
											name:res.data[i].firstname,
											cardid:res.data[i].firstcardid,
											roomid:res.data[i].roomid,
											casheveryday:res.data[i].casheveryday,
											deposit:res.data[i].deposit,
											prepaid:res.data[i].prepaid,
											cashtype:res.data[i].cashtype,
											state:res.data[i].state,
											allinfo:res.data[i],
											renewal:'续租',
											checkout:'退房'
										});
									}
								}
								that.setState({pcheckout});
								alert('更新完毕！');
							});
						}
					});
				});
			}
			if(pcheckout[num].cashtype == '会员' && money >= -5000){
				axios.post('/room/changepcheckin',{state:1,money,id:pcheckout[num].key}).then(res=>{
					axios.post('/resident/deduction',{state:3,money,moneyeveryday:pcheckout[num].casheveryday}).then(resone=>{
						num = num + 1 ; 
						if(num < len){
							callback(num);
						}
						if(num == len){
							var pcheckout = [];
							axios.get('/room/allpcheckinroom').then(res=>{
								for(var i = 0 ; i < res.data.length ; i++){
									if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
										pcheckout.push({
											key:res.data[i]._id,
											name:res.data[i].firstname,
											cardid:res.data[i].firstcardid,
											roomid:res.data[i].roomid,
											casheveryday:res.data[i].casheveryday,
											deposit:res.data[i].deposit,
											prepaid:res.data[i].prepaid,
											cashtype:res.data[i].cashtype,
											state:res.data[i].state,
											allinfo:res.data[i],
											renewal:'续租',
											checkout:'退房'
										});
									}
								}
								that.setState({pcheckout});
								alert('更新完毕！');
							});
						}
					});
				});
			}
			if(pcheckout[num].cashtype == '会员' && money < -5000){
				axios.post('/room/changepcheckin',{state:1,money,id:pcheckout[num].key}).then(res=>{
					axios.post('/resident/deduction',{state:3,money,moneyeveryday:pcheckout[num].casheveryday}).then(resone=>{
						axios.post('/room/changeroomstate',{state:5,roomid:pcheckout[num].roomid}).then(resone=>{
							num = num + 1 ; 
							if(num < len){
								callback(num);
							}
							if(num == len){
								var pcheckout = [];
								axios.get('/room/allpcheckinroom').then(res=>{
									for(var i = 0 ; i < res.data.length ; i++){
										if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
											pcheckout.push({
												key:res.data[i]._id,
												name:res.data[i].firstname,
												cardid:res.data[i].firstcardid,
												roomid:res.data[i].roomid,
												casheveryday:res.data[i].casheveryday,
												deposit:res.data[i].deposit,
												prepaid:res.data[i].prepaid,
												cashtype:res.data[i].cashtype,
												state:res.data[i].state,
												allinfo:res.data[i],
												renewal:'续租',
												checkout:'退房'
											});
										}
									}
									that.setState({pcheckout});
									alert('更新完毕！');
								});
							}
						});
					});
				});
			}
		}
		callback(0);
	}
} 
 
export default connect(
	null,
	{
		getclickcheckin(data){
			return {
				type:'clickcheckin',
				payload:data
			}
		}	
	}
)(Pcheckout); 