import React,{Component} from "react";
import {connect} from "react-redux";
 
import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
}
   
const pagination = {
	pageSize:6
}

class Pchrecord extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '入住代表名',
			  	dataIndex: 'name'
				}, 
				{
			 	title: '入住代表身份证号',
			  	dataIndex: 'cardid'
				},
			 	{
			  	title: '入住房间',
			 	dataIndex: 'roomid'
				},
				{
				title: '付款方式',
			 	dataIndex: 'cashtype'
				},
				{
				title:'当前状态',
				dataIndex: 'state'
				},
				{
				title:'操作',
				dataIndex:'view',
				className:'operation',
				render:(text,record)=><span onClick={this.view.bind(this,record.allinfo)}>{text}</span>
				}
			],
			allpcheckinroom : [],
			incheckinroom : [],
			endcheckinroom : [],
			owecheckinroom : [],
			baddebts:[]
		}
	} 
	componentWillMount(){
		var allpcheckinroom = [];
		var incheckinroom = [];
		var endcheckinroom = [];
		var owecheckinroom = [];
		var baddebts = [];
		axios.get('/room/allpcheckinroom').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				allpcheckinroom.push({
					key:res.data[i]._id,
					name:res.data[i].firstname,
					cardid:res.data[i].firstcardid,
					roomid:res.data[i].roomid,
					cashtype:res.data[i].cashtype,
					state:res.data[i].state,
					allinfo:res.data[i],
					view:'查看详情'
				});
			}
			for(var i = 0 ; i < allpcheckinroom.length ; i++){
				if(allpcheckinroom[i].state == '已入住'){
					incheckinroom.push(allpcheckinroom[i]);
				}
				if(allpcheckinroom[i].state == '已退房'){
					endcheckinroom.push(allpcheckinroom[i]);
				}
				if(allpcheckinroom[i].state == '已欠费'){
					owecheckinroom.push(allpcheckinroom[i]);
				}
				if(allpcheckinroom[i].state == '已成坏账'){
					baddebts.push(allpcheckinroom[i]);
				}
			}
			this.setState({allpcheckinroom,incheckinroom,endcheckinroom,owecheckinroom,baddebts});
		});
	} 
	render(){
		return (
			<section id="pchrecord">
				<Tabs defaultActiveKey="1" onChange={callback}>
					<TabPane tab="所有入住记录" key="1">
						<Table columns={this.state.columns} dataSource={this.state.allpcheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="入住中" key="2">
						<Table columns={this.state.columns} dataSource={this.state.incheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已退房" key="3">
						<Table columns={this.state.columns} dataSource={this.state.endcheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已欠费" key="4">
						<Table columns={this.state.columns} dataSource={this.state.owecheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已成坏账" key="5">
						<Table columns={this.state.columns} dataSource={this.state.baddebts} bordered pagination={pagination}/>
					</TabPane>
				</Tabs>
			</section>
			)
	}
	view(data){
		this.props.getclickcheckin(data);
		this.props.history.push('/home/checkindetail?1');
	}
}
  
export default connect(
	null,
	{ 
		getclickcheckin(data){
			return {
				type:'clickcheckin',
				payload:data
			}
		}	
	}
)(Pchrecord);