import React,{Component} from "react";
import {connect} from "react-redux";
 
import { Tabs,Form,Button} from 'antd';
const TabPane = Tabs.TabPane;
const FormItem = Form.Item;

function callback(key) {
	console.log(key);
}

class Personcheckin extends Component{
	constructor(){
		super();
		this.state = {
			roominfo:[],
			roomprice:[],
			allprice:[],
			vip:{flag:1,container:"非会员"},
			personum:[],
			allroomeveryday:0,
			allroomoney:0,
			formLayout: 'horizontal'
		}
	}
	componentWillMount(){
		//把所有的房间信息结合到一个对象中
		var allroomeveryday = 0 ;
		for(var i = 0 ; i < this.props.basecheckin.room.length; i++){
			for(var j = 0 ; j < this.props.roomprice.length ; j++){
				if(this.props.basecheckin.room[i].roomtype == this.props.roomprice[j].roomtype){
					var oneroominfo ={};
					oneroominfo.id = this.props.basecheckin.room[i]._id;
					oneroominfo.roomid = this.props.basecheckin.room[i].roomid;
					oneroominfo.roomtype = this.props.basecheckin.room[i].roomtype;
					oneroominfo.roomdeposit = this.props.roomprice[j].roomdeposit;
					oneroominfo.roomprice = this.props.roomprice[j].roomprice;
					oneroominfo.mostpeople = [];
					//为了通过不同ref值获取到节点
					for(var z = 0 ; z < this.props.roomprice[j].mostpeople ; z ++){
						oneroominfo.mostpeople.push({name:`name${oneroominfo.roomid}${z}`,cardid:`cardid${oneroominfo.roomid}${z}`});
					}
					break;
				}
			}
			allroomeveryday = allroomeveryday + oneroominfo.roomprice;
			this.state.roomprice.push(oneroominfo.roomprice);
			this.state.allprice.push(0);
			this.state.roominfo.push(oneroominfo);
		}
		this.setState({allroomeveryday,roomprice:this.state.roomprice,allprice:this.state.allprice,roominfo:this.state.roominfo});
		//团体入住
		if(location.search.substring(1) == 2){
			 for(var i = 0 ; i < parseInt(this.props.basecheckin.num) ; i++){
			 	this.state.personum.push({name:`name${i}`,cardid:`cardid${i}`});
				this.setState({personum:this.state.personum});
			 }	
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 4 },
		      wrapperCol: { span: 10 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		if(location.search.substring(1) == 1){
			//个人入住
			return (
				<section id="personcheckin">
					<Tabs defaultActiveKey="1" onChange={callback}>
					{
					this.state.roominfo.map((item,index)=>
						<TabPane tab={item.roomid} key={index+1}>
							<Form layout={formLayout}>
								<FormItem label="房间号：" {...formItemLayout} >
									{item.roomid}
								</FormItem>
								<FormItem label="房间类型：" {...formItemLayout} >
									{item.roomtype}
								</FormItem>
								<FormItem label="入住天数：" {...formItemLayout} >
									<input type="number" placeholder="请输入入住天数" onChange={this.changeday.bind(this,index,item)} ref={item.id}/>
								</FormItem>
								{
								item.mostpeople.map((items,index)=>
									<div key={items.name}>
										<span><input type="text"  placeholder="请输入入住人员姓名" ref={items.name}/></span>
										<span><input type="text"  placeholder="请输入入住人员身份证号码" ref={items.cardid}/></span>
									</div>
								)
								}
								<FormItem label="预交款：" {...formItemLayout} >
									<input type="number" placeholder="请输入付款金额" ref={item.roomid}/>
								</FormItem>
								<div><span className="operation" onClick={this.judge.bind(this,item,index)}>判断是否是vip：</span>{this.state.vip.container}</div>
								<FormItem label="押金：" {...formItemLayout} >
									{item.roomdeposit}
								</FormItem>
								<FormItem label="每日房价：" {...formItemLayout} >
									{this.state.roomprice[index]}
								</FormItem>
								<FormItem label="总价：" {...formItemLayout} >
									{this.state.allprice[index]}
								</FormItem>
								<FormItem {...buttonItemLayout}>
									<Button type="primary" onClick={this.submit.bind(this,item,index)}>提交</Button>
								</FormItem>
							</Form>
						</TabPane>
						)
					}
					</Tabs>
				</section>
				)
		}
		if(location.search.substring(1) == 2){
			return (
				<section id="personcheckin">
					<div className="personcheckin-title">入住人员登记信息</div>
					<Form layout={formLayout}>
						<FormItem label="请输入入住天数：" {...formItemLayout} >
							<input type='number' ref='num' onChange={this.changeday.bind(this)} />
						</FormItem>
						{
						this.state.personum.map((item,index)=>
							<div key={item.name}>
								<span><input type="text" placeholder='请输入入住人员姓名' ref={item.name}/></span>
								<span><input type="text" placeholder="请输入入住人员身份证号码" ref={item.cardid} /></span>
							</div>
						)
						}
						<FormItem label="预交款：" {...formItemLayout} >
							<input type="number" placeholder="请输入付款金额" ref='money'/>
						</FormItem>
						<div><span className="operation" onClick={this.judge.bind(this)}>判断是否是vip：</span>{this.state.vip.container}</div>
						<FormItem label="每日房价：" {...formItemLayout} >
							{this.state.allroomeveryday}
						</FormItem>
						<FormItem label="总价：" {...formItemLayout} >
							{this.state.allroomoney}
						</FormItem>
						<FormItem {...buttonItemLayout}>
							<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
						</FormItem>
					</Form>
				</section>
				)
		}
	}
	changeday(index,item){
		if(location.search.substring(1) == 1){
			this.state.allprice[index] = parseInt(this.refs[item.id].value)*this.state.roomprice[index]+item.roomdeposit;	
			this.setState({allprice:this.state.allprice});
		}
		if(location.search.substring(1) == 2){
			var allroomoney = this.state.allroomeveryday * parseInt(this.refs.num.value);
			this.setState({allroomoney});
		}
	}
	//判断每个房间第一位房客是否是会员
	judge(item,index){
		if(this.state.vip.flag == 2){
			alert('请不要重复点击！');
		}else{
			//个人入住判断vip  个人vip打8折
			if(location.search.substring(1) == 1){
				var oneperson = {};
				if(this.refs[item.mostpeople[0].name].value&&this.refs[item.mostpeople[0].cardid].value){
					oneperson.name = this.refs[item.mostpeople[0].name].value;
					oneperson.cardid = this.refs[item.mostpeople[0].cardid].value;
					axios.post('/resident/judgepersonvip',{oneperson}).then(res=>{
						if(res.data.length != 0){
							if(res.data[0].money >= 0){
								this.setState({vip:{flag:2,container:'会员'}});
								this.state.allprice[index] = parseInt(this.refs[item.id].value)*this.state.roomprice[index] * 0.8+item.roomdeposit;
								this.state.roomprice[index] = this.state.roomprice[index] * 0.8;
								this.setState({allprice:this.state.allprice,roomprice:this.state.roomprice});
								this.refs[item.roomid].value = parseInt(res.data[0].money);
							}else{
								alert('会员卡余额不足！');
							}
						}else{
							alert('很遗憾，您不是会员！');
						}
					});
				}else{
					alert('房间必须登记第一位住户以便判断会员！');
				}	
			}
			//团体入住判断vip 团体vip打7折
			if(location.search.substring(1) == 2){
				var oneperson = {};
				if(this.refs[this.state.personum[0].name].value && this.refs[this.state.personum[0].cardid].value){
					oneperson.name = this.refs[this.state.personum[0].name].value;
					oneperson.cardid = this.refs[this.state.personum[0].cardid].value;
					axios.post('/resident/judgeteamvip',{oneperson}).then(res=>{
						if(res.data.length != 0){
							if(res.data[0].money >= 0){
								var allroomeveryday = this.state.allroomeveryday * 0.7 ;
								var allroomoney = this.state.allroomoney * 0.7;
								this.setState({vip:{flag:2,container:'会员'},allroomeveryday,allroomoney});
								this.refs.money.value = parseInt(res.data[0].money);
							}else{
								alert('会员卡余额不足！');
							}
						}else{
							alert('很遗憾，您不是会员！');
						}
					});
				}else{
					alert('房间必须登记第一位住户以便判断会员！');
				}
			}
		}
	}
	submit(item,index){
		//个人入住
		if(location.search.substring(1) == 1){
			//获取入住人员信息
			var person = [];
			for(var i = 0 ; i < item.mostpeople.length ; i++){
				var oneperson = {};
				if(this.refs[item.mostpeople[i].name].value&&this.refs[item.mostpeople[i].cardid].value){
					oneperson.name = this.refs[item.mostpeople[i].name].value;
					oneperson.cardid = this.refs[item.mostpeople[i].cardid].value;
					person.push(JSON.stringify(oneperson));
				}
			}
			//修改房间状态
			axios.post('/room/changeroomstate',{
				state:3,
				id:item.id,
				person:person
			}).then(res=>{
				this.props.updateallroom();
				//修改用户信息
				axios.post('/resident/updateresident',{len:person.length,person}).then(resone=>{
					this.props.updateallresident();
					//添加入住记录
					axios.post('/room/pcheckinroom',{
						person,
						roomid:item.roomid,
						roomtype:item.roomtype,
						casheveryday:this.state.roomprice[index],
						deposit:item.roomdeposit,
						prepaid:parseInt(this.refs[item.roomid].value),
						cashtype:this.state.vip.container
					}).then(restwo=>{
						alert('登记入住成功！');
					});
				});

			});
		}
		if(location.search.substring(1) == 2){
			//获取入住人员信息
			var person = [];
			for(var i = 0 ; i < this.state.personum.length ; i++){
				var oneperson = {};
				if(this.refs[this.state.personum[i].name].value && this.refs[this.state.personum[i].cardid].value){
					oneperson.name = this.refs[this.state.personum[i].name].value;
					oneperson.cardid = this.refs[this.state.personum[i].cardid].value;
					person.push(JSON.stringify(oneperson));
				}else{
					break;
				} 
			}
			if(this.state.personum.length = person.length){
				//修改用户信息
				axios.post('/resident/updateresident',{len:person.length,person}).then(res=>{
					this.props.updateallresident();
					//修改房间状态
					axios.post('/room/changeroomstate',{
						state:4,
						len:this.state.roominfo.length,
						roominfo:this.state.roominfo,
						person:person
					}).then(res=>{
						this.props.updateallroom();
						//添加入住记录
						axios.post('/room/tcheckinroom',{
							person,
							roominfo:this.state.roominfo,
							casheveryday:this.state.allroomeveryday,
							prepaid:this.refs.money.value,
							cashtype:this.state.vip.container
						}).then(resone=>{
							alert("登记入住成功！");
						});
					});
				});
			}else{
				alert('有用户信息未填写！');
			}
		}	
	}
}

export default connect(
	(state)=>{
		return {
			basecheckin:state.basecheckin,
			roomprice:state.roomprice
		}
	},
	{
		updateallroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		},
		updateallresident(){
			return axios.get('/resident/allresident').then(res=>{
				return {
					type:'allresident',
					payload:res.data
				}
			});
		}
	}
	)(Personcheckin);