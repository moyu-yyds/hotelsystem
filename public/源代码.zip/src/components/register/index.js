import React,{Component} from 'react';
import {connect} from 'react-redux';

import { Form, Button } from 'antd';
const FormItem = Form.Item;

class Register extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	componentWillMount(){
		this.props.getalluser();
	}
	render(){
		if(this.props.userinfo.username == '管理员'){
			const { formLayout } = this.state;
			const formItemLayout = formLayout === 'horizontal' ? {
			      labelCol: { span: 6 },
			      wrapperCol: { span: 14 },
			    } : null;
			    const buttonItemLayout = formLayout === 'horizontal' ? {
			      wrapperCol: { span: 14, offset: 4 },
			    } : null;
			return (
				<section id="register">
					<div className="title">员工注册</div>
					<Form layout={formLayout}>
						<FormItem label="输入姓名:(必填)" {...formItemLayout} >
							<input type="text" placeholder='请输入姓名' ref='name'/>
						</FormItem>
						<FormItem label="选择性别：" {...formItemLayout} >
							<select ref='sex'>
								<option value='男'>男</option>
								<option value='女'>女</option>
							</select>
						</FormItem>
						<FormItem label="设置密码:(必填)" {...formItemLayout} >
							<input type="password" placeholder='请输入密码' ref='password'/>
						</FormItem>
						<FormItem label="输入证件号:(必填)" {...formItemLayout} >
							<input type="text" placeholder='请输入身份证号码' ref='cardid'/>
						</FormItem>
						<FormItem label="输入手机号:(必填)" {...formItemLayout} >
							<input type="text" placeholder='请输入手机号码' ref='phonenumber'/>
						</FormItem>
						<FormItem label="输入邮箱：" {...formItemLayout} >
							<input type="text" placeholder='请输入邮箱' ref='email'/>
						</FormItem>
						<FormItem label="输入生日：" {...formItemLayout} >
							<input type="text" placeholder='请输入出生日期' ref='birth'/>
						</FormItem>
						<FormItem label="输入居住地址：" {...formItemLayout} >
							<textarea placeholder='请输入居住地址' ref='address'></textarea>
						</FormItem>
						<FormItem {...buttonItemLayout}>
							<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
						</FormItem>
					</Form>
				</section>
				)
		}else{
			return (
				<section id="permissions">
					您没有此项权限！
				</section>
				)
		}
	}
	submit(){
		var username = this.refs.name.value ;
		var sex = this.refs.sex.value ;
		var password = this.refs.password.value ;
		var cardid = this.refs.cardid.value ;
		var phonenumber = this.refs.phonenumber.value ;
		var email = this.refs.email.value ;
		var birth = this.refs.birth.value ;
		var address = this.refs.address.value ;
		if(username && sex && password && cardid && phonenumber){
			//手机号码不能重复且不能起名为管理员
			for(var i = 0 ; i < this.props.alluser.length ; i++){
				if(phonenumber == this.props.alluser[i].phonenumber){
					break;
				}
			}
			if(i == this.props.alluser.length && username != "管理员"){
				axios.post('/user/newuser',{username,sex,password,cardid,phonenumber,email,birth,address}).then(res=>{
					this.props.getalluser();
					alert('成功注册！');
					this.props.history.push('/home/roomprice');
				});	
			}else{
				alert('您的信息填写有误！');
			}	
		}else{
			alert("您有信息未填写完整！");
		}

	}
}

export default connect(
	(state)=>{
		return {
			userinfo:state.userinfo,
			alluser:state.alluser
		}
	},
	{
		getalluser(){
			return axios.get('/user/alluser').then(res=>{
				return {
					type:'alluser',
					payload:res.data
				}
			});
		}
	}
)(Register) ; 