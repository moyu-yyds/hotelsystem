import React,{Component} from "react";
import {connect} from "react-redux";

import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
}
 
const pagination = {
	pageSize:6
}

class Resermanage extends Component{
	constructor(){
		super();
		this.state = {
			columns:[
				{
				title: '姓名',
				dataIndex: 'name'
				}, 
				{
				title: '身份证号',
				dataIndex: 'cardid'
				},
				{
				title: '预定类型',
				dataIndex: 'form'	
				},
				{
				title: '预定状态',
				dataIndex: 'state'		
				},
				{
				title: '操作1',
				dataIndex: 'view',
				className:'operation',
				render:(text,record)=><span onClick={this.view.bind(this,record.allinfo)}>{text}</span>
				},
				{
				title: '操作2',
				dataIndex: 'cancel',
				className:'operation',
				render:(text,record)=><span onClick={this.cancel.bind(this,record.allinfo)}>{text}</span>
				}
			],
			allreservation:[],
			inthebook:[],
			complete:[],
			cancel:[]
		}
	}
	componentWillMount(){
		axios.get('/room/allreservation').then(res=>{
			var allreservation = [] ; 
			var inthebook = [];
			var complete = [];
			var cancel = [];
			for(var i = 0 ; i < res.data.length ; i++){
				allreservation.push({
					key:res.data[i]._id,
					name:res.data[i].name,
					cardid:res.data[i].cardid,
					form:res.data[i].form,
					state:res.data[i].state,
					allinfo:res.data[i],
					view:'查看',
					cancel:'取消预定'
				});
			}
			for(var i = 0 ; i < allreservation.length ; i++){
				if(allreservation[i].state == '预定中'){
					inthebook.push(allreservation[i]);
				}
				if(allreservation[i].state == '已完成'){
					complete.push(allreservation[i]);
				}
				if(allreservation[i].state == '已取消'){
					cancel.push(allreservation[i]);
				}
			}
			this.setState({allreservation,inthebook,complete,cancel});
		});
	}
	render(){
		return (
			<section id="resermanage">
				<Tabs defaultActiveKey="1" onChange={callback}>
					<TabPane tab="所有预定记录" key="1">
						<Table columns={this.state.columns} dataSource={this.state.allreservation} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="预定中" key="2">
						<Table columns={this.state.columns} dataSource={this.state.inthebook} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已完成" key="3">
						<Table columns={this.state.columns} dataSource={this.state.complete} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已取消" key="4">
						<Table columns={this.state.columns} dataSource={this.state.cancel} bordered pagination={pagination}/>
					</TabPane>
				</Tabs>
			</section>
			)
	}
	view(item){
		this.props.getreservationitem(item);
		this.props.history.push('/home/reservationdetail');
	}
	cancel(allinfo){
		if(allinfo.state == '预定中'){
			var roominfo = [];
			for(var i = 0 ; i < allinfo.roominfo.length ; i++){
				roominfo.push(JSON.parse(allinfo.roominfo[i]));
			}
			axios.post('/room/changereservation',{state:2,id:allinfo._id}).then(res=>{
				axios.get('/room/allreservation').then(res=>{
					var allreservation = [] ; 
					var inthebook = [];
					var complete = [];
					var cancel = [];
					for(var i = 0 ; i < res.data.length ; i++){
						allreservation.push({
							key:res.data[i]._id,
							name:res.data[i].name,
							cardid:res.data[i].cardid,
							form:res.data[i].form,
							state:res.data[i].state,
							allinfo:res.data[i],
							view:'查看',
							cancel:'取消预定'
						});
					}
					for(var i = 0 ; i < allreservation.length ; i++){
						if(allreservation[i].state == '预定中'){
							inthebook.push(allreservation[i]);
						}
						if(allreservation[i].state == '已完成'){
							complete.push(allreservation[i]);
						}
						if(allreservation[i].state == '已取消'){
							cancel.push(allreservation[i]);
						}
					}
					this.setState({allreservation,inthebook,complete,cancel});
					var roominfo = [];
					for(var i = 0 ; i < allinfo.roominfo.length ; i++){
						var oneroom = JSON.parse(allinfo.roominfo[i]);
						roominfo.push({id:oneroom._id});
					}
					axios.post('/room/changeroomstate',{state:6,len:roominfo.length,roominfo}).then(res=>{
						this.props.getallroom();
						alert('取消成功！');
					});
					
				});
			});
		}else{
			alert('该预定目前不可取消！');
		}
		
	}
}

export default connect(
	(state)=>{
		return {
			allreservation:state.allreservation
		}
	},
	{
		getreservationitem(item){
			return {
				type:'reservationitem',
				payload:item
			}
		},
		getallroom(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		}
	}
)(Resermanage);