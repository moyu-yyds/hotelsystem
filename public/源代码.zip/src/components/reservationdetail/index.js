import React,{Component} from "react";
import {connect} from "react-redux";

import { Form, Button,Table } from 'antd';
const FormItem = Form.Item;

const pagination = {
	pageSize:6
}

class Reservationdetail extends Component{
	constructor(){
		super();
		this.state = {
			roominfo:[],
			formLayout: 'horizontal',
			columns:[
				{
				title: '房间号',
				dataIndex: 'roomid'
				},    	
				{
				title: '房间类型',
				dataIndex: 'roomtype'
				}
			],
		}
	}
	componentWillMount(){
		var roominfo = [];
		for(var i = 0 ; i < this.props.reservationinfo.roominfo.length ; i++){
			var oneroom = JSON.parse(this.props.reservationinfo.roominfo[i]);
			roominfo.push({
				key:oneroom._id,
				roomid:oneroom.roomid,
				roomtype:oneroom.roomtype
			});
		}
		this.setState({roominfo});
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="reservationdetail">
				<div className="title">预订详细信息</div>
				<FormItem label="预定者姓名：" {...formItemLayout} >
					{this.props.reservationinfo.name}
				</FormItem>
				<FormItem label="预定者身份证号码：" {...formItemLayout} >
					{this.props.reservationinfo.cardid}
				</FormItem>
				<FormItem label="预定入住人数：" {...formItemLayout} >
					{this.props.reservationinfo.personumber}
				</FormItem>
				<FormItem label="预定类型：" {...formItemLayout} >
					{this.props.reservationinfo.form}
				</FormItem>
				<FormItem label="预定状态：" {...formItemLayout} >
					{this.props.reservationinfo.state}
				</FormItem>
				<div className="reservationdetail-roominfo">所选房间</div>
				<Table columns={this.state.columns} dataSource={this.state.roominfo} bordered pagination={pagination}/>
			</section>
			)
	}
}

export default connect(
	(state)=>{
		return {
			reservationinfo:state.reservationitem,
		}
	},
	null
)(Reservationdetail);