import React,{Component} from "react" ;
import {connect} from "react-redux";

import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
}
   
const pagination = {
	pageSize:6
}

class Room extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '房间号',
			  	dataIndex: 'roomid'
				}, 
				{
			 	title: '房间类型',
			  	dataIndex: 'roomtype'
				},
			 	{
			  	title: '房间状态',
			 	dataIndex: 'state'
				}
			],
			allroom:[],
			singleroom:[],
			standardroom:[],
			bigbedroom:[],
			threebedroom:[],
			businessroom:[],
		}
	}
	componentWillMount(){
		var allroom = [];
		var singleroom = [];
		var standardroom = [] ;
		var bigbedroom = [] ;
		var threebedroom = [] ;
		var businessroom = [] ;
		for(var i = 0 ; i < this.props.room.length ; i++){
			allroom.push({
				key:this.props.room[i]._id,
				roomid:this.props.room[i].roomid,
				roomtype:this.props.room[i].roomtype,
				state:this.props.room[i].state
			});
		}
		for(var i = 0 ; i < allroom.length ; i ++){
			if(allroom[i].roomtype == '单人间'){
				singleroom.push(allroom[i]);
			}
			if(allroom[i].roomtype == '标准间'){
				standardroom.push(allroom[i]);
			}
			if(allroom[i].roomtype == '大床间'){
				bigbedroom.push(allroom[i]);
			}
			if(allroom[i].roomtype == '三人间'){
				threebedroom.push(allroom[i]);
			}
			if(allroom[i].roomtype == '商务间'){
				businessroom.push(allroom[i]);
			}
		}
		this.setState({allroom,singleroom,standardroom,bigbedroom,threebedroom,businessroom});
	}
	render(){ 
		return (
			<section id="room">
				<Tabs defaultActiveKey="1" onChange={callback}>
					<TabPane tab="所有房间" key="1">
						<Table columns={this.state.columns} dataSource={this.state.allroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="单人间" key="2">
						<Table columns={this.state.columns} dataSource={this.state.singleroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="标准间" key="3">
						<Table columns={this.state.columns} dataSource={this.state.standardroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="大床间" key="4">
						<Table columns={this.state.columns} dataSource={this.state.bigbedroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="三人间" key="5">
						<Table columns={this.state.columns} dataSource={this.state.threebedroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="商务间" key="6">
						<Table columns={this.state.columns} dataSource={this.state.businessroom} bordered pagination={pagination}/>
					</TabPane>
				</Tabs>
			</section>
			 )
	}
} 

export default connect(
	(state)=>{
		return {
			room:state.allroom
		}
	},
	null
	)(Room);