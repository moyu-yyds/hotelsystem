import React,{Component} from "react";
import {connect} from "react-redux";

import { Table } from 'antd';

const pagination = {
	pageSize:6
}

class Roomprice extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '房间类型',
			  	dataIndex: 'roomtype',
				}, 
				{
			 	title: '房间押金',
			  	dataIndex: 'roomdeposit',
				},
			  	{
			  	 title:"房间价格",
			  	 dataIndex:'roomprice'
			  	},
			  	{
			  	 title:"最多居住人数",
			  	 dataIndex:'mostpeople',
			  	},
			  	{
			  	 title:"操作",
			  	 dataIndex:'update',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.update.bind(this,record.allinfo)}>{text}</span>
			  	}
			],
			roomprice:[]
		}
	}
	componentWillMount(){
		var roomprice = [];
		axios.get('/room/roomprice').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				roomprice.push({
					key:res.data[i]._id,
					roomtype:res.data[i].roomtype,
					roomdeposit:res.data[i].roomdeposit,
					roomprice:res.data[i].roomprice,
					mostpeople:res.data[i].mostpeople,
					update:'更新',
					//方便把信息传入详情页面
					allinfo:res.data[i]
				});
			}
			this.setState({roomprice});
		})
	}
	render(){ 
		return (
			<section id="roomprice">
				<Table columns={this.state.columns} dataSource={this.state.roomprice} bordered pagination={pagination}/>
			</section>
			)
	}
	update(item){
		this.props.getclickroomprice(item);
		this.props.history.push('/home/updateroomprice');
	}
}

export default connect(
	(state)=>{
		return {
			roomprice:state.roomprice
		}
	},
	{
		getclickroomprice(item){
			return {
				type:'clickroomprice',
				payload:item
			}
		}
	}
	)(Roomprice) ;
