import React,{Component} from "react";
import {connect} from "react-redux";
 
import { Table } from 'antd';
  
const pagination = {
	pageSize:6
}

class Tcheckout extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '入住代表名',
			  	dataIndex: 'name'
				}, 
				{
			 	title: '入住代表身份证号',
			  	dataIndex: 'cardid'
				},
				{
			 	title: '每日花费',
			  	dataIndex: 'casheveryday'
				},
				{
			 	title: '剩余金额',
			  	dataIndex: 'prepaid'
				},
				{
			 	title: '付款方式',
			  	dataIndex: 'cashtype'
				},
				{
			 	title: '当前状态',
			  	dataIndex: 'state'
				},
			  	{
			  	 title:"操作1",
			  	 dataIndex:'renewal',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.renewal.bind(this,record.allinfo)}>{text}</span>
			  	},
			  	{ 
			  	 title:"操作2",
			  	 dataIndex:'checkout',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.checkout.bind(this,record.allinfo)}>{text}</span>
			  	}
			],
			tcheckout:[]
		}
	}
	componentWillMount(){
		var tcheckout = [];
		axios.get('/room/alltcheckinroom').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
					tcheckout.push({
						key:res.data[i]._id,
						name:res.data[i].firstname,
						cardid:res.data[i].firstcardid,
						casheveryday:res.data[i].casheveryday,
						prepaid:res.data[i].prepaid,
						cashtype:res.data[i].cashtype,
						state:res.data[i].state,
						allinfo:res.data[i],
						renewal:'续租',
						checkout:'退房'
					});
				}
			}
			this.setState({tcheckout});
		});
	}
	render(){
		return (
			<section id="tcheckout">
				<div className="operation oneday" onClick={this.oneday.bind(this)}>一天时间过去了...</div>
				<Table columns={this.state.columns} dataSource={this.state.tcheckout} bordered pagination={pagination}/>
			</section>
			)
	} 
	renewal(data){
		this.props.getclickcheckin(data);
		this.props.history.push('/home/topup?3');
	}
	checkout(data){
		this.props.getclickcheckin(data);
		this.props.history.push('/home/checkout?2');
	}
	oneday(){
		var tcheckout = this.state.tcheckout;
		var len = tcheckout.length ;
		var that = this;
		function callback(num){
			var money = tcheckout[num].prepaid - tcheckout[num].casheveryday;
			if(tcheckout[num].cashtype == '非会员' && money >= -5000){
				axios.post('/room/changetcheckin',{state:1,money,id:tcheckout[num].key}).then(res=>{
					num = num + 1 ; 
					if(num < len){
						callback(num);
					}
					if(num == len){
						var tcheckout = [];
						axios.get('/room/alltcheckinroom').then(res=>{
							for(var i = 0 ; i < res.data.length ; i++){
								if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
									tcheckout.push({
										key:res.data[i]._id,
										name:res.data[i].firstname,
										cardid:res.data[i].firstcardid,
										casheveryday:res.data[i].casheveryday,
										prepaid:res.data[i].prepaid,
										cashtype:res.data[i].cashtype,
										state:res.data[i].state,
										allinfo:res.data[i],
										renewal:'续租',
										checkout:'退房'
									});
								}
							}
							that.setState({tcheckout});
							alert("更新成功！");
						});
					}
				});
			}
			if(tcheckout[num].cashtype == '非会员' && money < -5000){
				axios.post('/room/changetcheckin',{state:1,money,id:tcheckout[num].key}).then(res=>{
					axios.post('/room/changeroomstate',{state:6,roominfo:tcheckout[num].allinfo.roominfo,len:tcheckout[num].allinfo.roominfo.length}).then(resone=>{
						num = num + 1 ; 
						if(num < len){
							callback(num);
						}
						if(num == len){
							var tcheckout = [];
							axios.get('/room/alltcheckinroom').then(res=>{
								for(var i = 0 ; i < res.data.length ; i++){
									if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
										tcheckout.push({
											key:res.data[i]._id,
											name:res.data[i].firstname,
											cardid:res.data[i].firstcardid,
											casheveryday:res.data[i].casheveryday,
											prepaid:res.data[i].prepaid,
											cashtype:res.data[i].cashtype,
											state:res.data[i].state,
											allinfo:res.data[i],
											renewal:'续租',
											checkout:'退房'
										});
									}
								}
								that.setState({tcheckout});
								alert("更新成功！");
							});
						}
					});
				});
			}
			if(tcheckout[num].cashtype == "会员" && money >= -5000){
				axios.post('/room/changetcheckin',{state:1,money,id:tcheckout[num].key}).then(res=>{
					axios.post('/resident/deduction',{state:4,money,moneyeveryday:tcheckout[num].casheveryday}).then(resone=>{
						num = num + 1 ; 
						if(num < len){
							callback(num);
						}
						if(num == len){
							var tcheckout = [];
							axios.get('/room/alltcheckinroom').then(res=>{
								for(var i = 0 ; i < res.data.length ; i++){
									if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
										tcheckout.push({
											key:res.data[i]._id,
											name:res.data[i].firstname,
											cardid:res.data[i].firstcardid,
											casheveryday:res.data[i].casheveryday,
											prepaid:res.data[i].prepaid,
											cashtype:res.data[i].cashtype,
											state:res.data[i].state,
											allinfo:res.data[i],
											renewal:'续租',
											checkout:'退房'
										});
									}
								}
								that.setState({tcheckout});
								alert("更新成功！");
							});
						}
					});
				})
			}
			if(tcheckout[num].cashtype == "会员" && money < -5000){
				axios.post('/room/changetcheckin',{state:1,money,id:tcheckout[num].key}).then(res=>{
					axios.post('/room/changeroomstate',{state:6,roominfo:tcheckout[num].allinfo.roominfo,len:tcheckout[num].allinfo.roominfo.length}).then(resone=>{
						axios.post('/resident/deduction',{state:4,money,moneyeveryday:tcheckout[num].casheveryday}).then(restwo=>{
							num = num + 1 ; 
							if(num < len){
								callback(num);
							}
							if(num == len){
								var tcheckout = [];
								axios.get('/room/alltcheckinroom').then(res=>{
									for(var i = 0 ; i < res.data.length ; i++){
										if(res.data[i].state == "已入住" || res.data[i].state == "已欠费"){
											tcheckout.push({
												key:res.data[i]._id,
												name:res.data[i].firstname,
												cardid:res.data[i].firstcardid,
												casheveryday:res.data[i].casheveryday,
												prepaid:res.data[i].prepaid,
												cashtype:res.data[i].cashtype,
												state:res.data[i].state,
												allinfo:res.data[i],
												renewal:'续租',
												checkout:'退房'
											});
										}
									}
									that.setState({tcheckout});
									alert("更新成功！");
								});
							}
						});
					});
				});
			}
		}
		callback(0);
	}
}

export default connect(
	null,
	{
		getclickcheckin(data){
			return {
				type:'clickcheckin',
				payload:data
			}
		}	
	}
)(Tcheckout); 