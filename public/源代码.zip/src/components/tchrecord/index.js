import React,{Component} from "react";
import {connect} from "react-redux";

import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
}
   
const pagination = {
	pageSize:6
}

class Tchrecord extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '入住代表名',
			  	dataIndex: 'name'
				}, 
				{
			 	title: '入住代表身份证号',
			  	dataIndex: 'cardid'
				},
				{
				title: '付款方式',
			 	dataIndex: 'cashtype'
				},
				{
				title:'当前状态',
				dataIndex: 'state'
				},
				{
				title:'操作',
				dataIndex:'view',
				className:'operation',
				render:(text,record)=><span onClick={this.view.bind(this,record.allinfo)}>{text}</span>
				}
			],
			alltcheckinroom : [],
			incheckinroom : [],
			endcheckinroom : [],
			owecheckinroom : []
		}
	} 
	componentWillMount(){
		var alltcheckinroom = [];
		var incheckinroom = [];
		var endcheckinroom = [];
		var owecheckinroom = [];
		var baddebts = [];
		axios.get('/room/alltcheckinroom').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				alltcheckinroom.push({
					key:res.data[i]._id,
					name:res.data[i].firstname,
					cardid:res.data[i].firstcardid,
					cashtype:res.data[i].cashtype,
					state:res.data[i].state,
					allinfo:res.data[i],
					view:'查看详情'
				});
			}
			for(var i = 0 ; i < alltcheckinroom.length ; i++){
				if(alltcheckinroom[i].state == '已入住'){
					incheckinroom.push(alltcheckinroom[i]);
				}
				if(alltcheckinroom[i].state == '已退房'){
					endcheckinroom.push(alltcheckinroom[i]);
				}
				if(alltcheckinroom[i].state == '已欠费'){
					owecheckinroom.push(alltcheckinroom[i]);
				}
				if(alltcheckinroom[i].state == '已成坏账'){
					baddebts.push(alltcheckinroom[i]);
				}
			}
			this.setState({alltcheckinroom,incheckinroom,endcheckinroom,owecheckinroom});
		});
	} 
	render(){
		return (
			<section id="tchrecord">
				<Tabs defaultActiveKey="1" onChange={callback}>
					<TabPane tab="所有入住记录" key="1">
						<Table columns={this.state.columns} dataSource={this.state.alltcheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已入住" key="2">
						<Table columns={this.state.columns} dataSource={this.state.incheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已退房" key="3">
						<Table columns={this.state.columns} dataSource={this.state.endcheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已欠费" key="4">
						<Table columns={this.state.columns} dataSource={this.state.owecheckinroom} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="已成坏账" key="5">
						<Table columns={this.state.columns} dataSource={this.state.baddebts} bordered pagination={pagination}/>
					</TabPane>
				</Tabs>
			</section>
			)
	}
	view(data){
		this.props.getclickcheckin(data);
		this.props.history.push('/home/checkindetail?2');
	}
}
 
export default connect(
	null,
	{
		getclickcheckin(data){
			return {
				type:'clickcheckin',
				payload:data
			}
		}
	}
)(Tchrecord);