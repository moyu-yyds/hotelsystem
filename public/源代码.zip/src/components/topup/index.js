import React,{Component} from "react";
import {connect} from "react-redux";
 
import { Form, Button } from 'antd';
const FormItem = Form.Item;

class Topup extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		} : null;
		const buttonItemLayout = formLayout === 'horizontal' ? {
		     wrapperCol: { span: 14, offset: 4 },
		} : null;
		if(location.search.substring(1) == 1){
			return (
				<section id="topup">
					<div className="title">充值</div>
					<Form layout={formLayout}>
						<FormItem label="会员姓名：" {...formItemLayout} >
							{this.props.vipinfo.username}
						</FormItem>
						<FormItem label="会员身份证号码：" {...formItemLayout} >
							{this.props.vipinfo.usercardid}
						</FormItem>
						<FormItem label="会员类型：" {...formItemLayout} >
							{this.props.vipinfo.viptype}
						</FormItem>
						<FormItem label="剩余钱数：" {...formItemLayout} >
							{this.props.vipinfo.money}
						</FormItem>
						<FormItem label="充值金额：" {...formItemLayout} >
							<input type="number" ref="money"/>
						</FormItem>
						<FormItem {...buttonItemLayout}>
							<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
						</FormItem>
					</Form>
				</section>
				)
		}
		if(location.search.substring(1) == 2){
			//个人续租
			return (
				<section id="topup">
					<div className="title">个人用户续租</div>
					<Form layout={formLayout}>
						<FormItem label="入住代表姓名：" {...formItemLayout} >
							{this.props.clickcheckin.firstname}
						</FormItem>
						<FormItem label="入住代表身份证号码：" {...formItemLayout} >
							{this.props.clickcheckin.firstcardid}
						</FormItem>
						<FormItem label="房间号：" {...formItemLayout} >
							{this.props.clickcheckin.roomid}
						</FormItem>
						<FormItem label="付款方式：" {...formItemLayout} >
							{this.props.clickcheckin.cashtype}
						</FormItem>
						<FormItem label="剩余钱数：" {...formItemLayout} >
							{this.props.clickcheckin.prepaid}
						</FormItem>
						<FormItem label="充值金额：" {...formItemLayout} >
							<input type="number" ref="money"/>
						</FormItem>
						<FormItem {...buttonItemLayout}>
							<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
						</FormItem>
					</Form>
				</section>
				)
		}
		if(location.search.substring(1) == 3){
			//团体续租
			return (
				<section id="topup">
					<div className="title">团体用户续租</div>
					<Form layout={formLayout}>
						<FormItem label="入住代表姓名：" {...formItemLayout} >
							{this.props.clickcheckin.firstname}
						</FormItem>
						<FormItem label="入住代表身份证号码：" {...formItemLayout} >
							{this.props.clickcheckin.firstcardid}
						</FormItem>
						<FormItem label="付款方式：" {...formItemLayout} >
							{this.props.clickcheckin.cashtype}
						</FormItem>
						<FormItem label="剩余钱数：" {...formItemLayout} >
							{this.props.clickcheckin.prepaid}
						</FormItem>
						<FormItem label="充值金额：" {...formItemLayout} >
							<input type="number" ref="money"/>
						</FormItem>
						<FormItem {...buttonItemLayout}>
							<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
						</FormItem>
					</Form>
				</section>
				)
		}
	}
	submit(){
		if(this.refs.money.value){
			if(location.search.substring(1) == 1){
				var allmoney = parseInt(this.props.vipinfo.money) + parseInt(this.refs.money.value) ;
				axios.post('/resident/updatevip',{
					id:this.props.vipinfo._id,
					viptype:this.props.vipinfo.viptype,
					record:this.props.vipinfo.record,
					allmoney,
					money:this.refs.money.value
				}).then(res=>{	
					axios.post('/room/renewal',{state:0,type:this.props.vipinfo.viptype,money:allmoney,name:this.props.vipinfo.username,cardid:this.props.vipinfo.usercardid}).then(resone=>{
						alert('充值成功！');
						this.props.history.push('/home/vipmanagement');
					});
				});
			} 
			if(location.search.substring(1) == 2){
				var money = parseInt(this.refs.money.value) + parseInt(this.props.clickcheckin.prepaid);
				if(this.props.clickcheckin.cashtype == '非会员'){
					axios.post('/room/renewal',{state:1,id:this.props.clickcheckin._id,money}).then(res=>{
						alert('续费成功！')
					});
				}
				if(this.props.clickcheckin.cashtype == '会员'){
					axios.post('/room/renewal',{state:1,id:this.props.clickcheckin._id,money}).then(res=>{
						axios.post('/resident/viprenewal',{state:1,name:this.props.clickcheckin.firstname,cardid:this.props.clickcheckin.firstcardid,money}).then(restwo=>{
							alert('续费成功！');
						});
					});
				}
			}
			if(location.search.substring(1) == 3){
				var money = parseInt(this.refs.money.value) + parseInt(this.props.clickcheckin.prepaid);
				if(this.props.clickcheckin.cashtype == '非会员'){
					axios.post('/room/renewal',{state:2,id:this.props.clickcheckin._id,money}).then(res=>{
						alert('续费成功！')
					});
				}
				if(this.props.clickcheckin.cashtype == '会员'){
					axios.post('/room/renewal',{state:2,id:this.props.clickcheckin._id,money}).then(res=>{
						axios.post('/resident/viprenewal',{state:2,name:this.props.clickcheckin.firstname,cardid:this.props.clickcheckin.firstcardid,money}).then(restwo=>{
							alert('续费成功！');
						});
					});
				}
			}
		}else{
			alert('尚未填写金额！');
		}
	}
}

export default connect(
	(state)=>{
		return {
			vipinfo:state.vipinfo,
			clickcheckin:state.clickcheckin
		}
	},
	null
)(Topup);