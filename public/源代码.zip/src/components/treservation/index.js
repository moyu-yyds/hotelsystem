import React,{Component} from "react";
import {connect} from "react-redux";

import { Form, Button,Table } from 'antd';
const FormItem = Form.Item;

const pagination = {
	pageSize:6
}
  
class Preservation extends Component{
	constructor(){
		super();
		this.state = {
			chosenroom:[],
			formLayout: 'horizontal',
			columns:[
				{
				title: '房间号',
				dataIndex: 'roomid'
				},    	
				{
				title: '房间类型',
				dataIndex: 'roomtype'
				}
			],
			chosenroom:[]
			}
		}
	 componentWillMount(){
	 	if(location.search.substring(1) == 1){
	 		this.props.initchosenroom();	
			this.props.initreservationinfo(); 	
			this.props.getallreservation();	
	 	}
	 	if(location.search.substring(1) == 22){
	 		var chosenroom = [];
	 		for(var i = 0 ; i < this.props.chosenroom.length ; i++){
	 			chosenroom.push({
	 				key:this.props.chosenroom[i]._id,
	 				roomid:this.props.chosenroom[i].roomid,
	 				roomtype:this.props.chosenroom[i].roomtype
	 			});
	 		}
	 		this.setState({chosenroom});
	 	}
	 }
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="preservation">
				<div className="title">团体预定</div>
				<FormItem label="预定者姓名：" {...formItemLayout} >
					<input type="text" placeholder={this.props.reservationinfo.name?this.props.reservationinfo.name:"预订者姓名"} ref="name"/>
				</FormItem>
				<FormItem label="预定者身份证号：" {...formItemLayout} >
					<input type="text" placeholder={this.props.reservationinfo.cardid?this.props.reservationinfo.cardid:"预订者身份证号码"} ref="cardid" />
				</FormItem>
				<FormItem label="入住人数：" {...formItemLayout} >
					<input type='number' placeholder={this.props.reservationinfo.personumber} ref="personumber" />
				</FormItem>
				<div className="operation" onClick={this.jumptochoose.bind(this,22)}>选择房间</div>
				<Table columns={this.state.columns} dataSource={this.state.chosenroom} bordered pagination={pagination}/>
				<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
			</section>
			)
	}
	jumptochoose(num){
		var name = this.refs.name.value;
		var cardid = this.refs.cardid.value;
		var personumber = this.refs.personumber.value;
		if(name == '' || cardid == '' || personumber == ''){
			alert('有信息未填写完整！');
		}else{
			//判断预定者是否已经预定过或已经入住
			for(var i = 0 ; i < this.props.allreservation.length ; i++){
				if(this.props.allreservation[i].name == name && this.props.allreservation[i].cardid == cardid && this.props.allreservation[i].state == '预定中'){
					alert('请勿重复预定！');
					break;
				}
			}
			if(i == this.props.allreservation.length){
				this.props.getreservationinfo({name,cardid,personumber});
				this.props.history.push(`/home/chooseroom?${num}`);
			}
		}
	}
	submit(num){
		if(this.props.chosenroom.length == 0){
			alert('还未选择房间！');
		}else{
			//将选择的房间信息转化为字符串保存到数据库中
			var roominfo = [];
			for(var i = 0 ; i < this.props.chosenroom.length ;  i++){
				roominfo.push(JSON.stringify(this.props.chosenroom[i]));
			}
			var data = {
				name:this.props.reservationinfo.name,
				cardid:this.props.reservationinfo.cardid,
				personumber:this.props.reservationinfo.personumber,
				roominfo,
				form:'团体预定'
			}
			axios.post('/room/reservation',{data}).then(resone=>{
				axios.post('/room/changeroomstate',{state:0,len:this.props.chosenroom.length,data:this.props.chosenroom}).then(restwo=>{
					this.setState({chosenroom:[]});
					this.props.initreservationinfo(); 	
					this.props.getallreservation();
					this.props.updateroomstate();
					alert('预定成功！');
				});
			});	
		}
	}
} 

export default connect(
	(state)=>{
		return {
			chosenroom:state.chosenroom,
			reservationinfo:state.reservationinfo,
			allreservation:state.allreservation
			}
	},
	{
		/*
		如果不初始化，那么一开始就会显示出上个客人信息
		 */
		initchosenroom(){
			return {
				type:'chosenroom',
				payload:[]
			}
		},
		initreservationinfo(){
			return {
				type:'reservationinfo',
				payload:{name:'',cardid:'',personumber:0}
			}
		},
		getallreservation(){
			return axios.get('/room/allreservation').then(res=>{
				return {
					type:'allreservation',
					payload:res.data
				}
			});
		},
		getreservationinfo(info){
			return {
				type:'reservationinfo',
				payload:info
			}
		},
		/*更新房间状态*/
		updateroomstate(){
			return axios.get('/room/allroom').then(res=>{
				return {
					type:'allroom',
					payload:res.data
				}
			});
		}
	})(Preservation) ;