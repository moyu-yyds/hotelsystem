import React,{Component} from 'react';
import {connect} from 'react-redux';

import { Form, Button } from 'antd';
const FormItem = Form.Item;

class Updateroomprice extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	render(){
		if(this.props.userinfo.username == '管理员'){
			const { formLayout } = this.state;
			const formItemLayout = formLayout === 'horizontal' ? {
			      labelCol: { span: 4 },
			      wrapperCol: { span: 14 },
			    } : null;
			    const buttonItemLayout = formLayout === 'horizontal' ? {
			      wrapperCol: { span: 14, offset: 4 },
			    } : null;
			return (
				<section id="updateroomprice" className="commonone">
					<div className="title">房间信息更新</div>
					<Form layout={formLayout}>
						<FormItem label="房间类型：" {...formItemLayout} >
							{this.props.roominfo.roomtype}
						</FormItem>
						<FormItem label="房间押金：" {...formItemLayout} >
							<input type='number' placeholder={this.props.roominfo.roomdeposit} ref="deposit"/>
						</FormItem>
						<FormItem label="房间价格：" {...formItemLayout} >
							<input type='number'  placeholder={this.props.roominfo.roomprice} ref="roomprice"/>
						</FormItem>
						<FormItem label="最多居住人数：" {...formItemLayout} >
							<input type='number' placeholder={this.props.roominfo.mostpeople} ref="mostpeople"/>
						</FormItem>
					</Form>
					<FormItem {...buttonItemLayout}>
						<Button type="primary" onClick={this.submit.bind(this)}>提交</Button>
					</FormItem>
				</section>
				)
		}else{
			return (
				<section id="permissions">
					您没有此项权限！
				</section>
				)
		}
	}
	submit(){
		var deposit = parseInt(this.refs.deposit.value) ;
		var roomprice = parseInt(this.refs.roomprice.value) ;
		var mostpeople = parseInt(this.refs.mostpeople.value) ;
		console.log(this.props.roominfo._id);
		if(deposit && roomprice && mostpeople){
			axios.post('/room/updateroomprice',{id:this.props.roominfo._id,deposit,roomprice,mostpeople}).then(res=>{
				alert('更新成功！');
				this.props.getroomprice();
				this.props.history.push('/home/roomprice');
				console.log(res.data);
			});
		}else{
			alert('信息未填写完整！');
		}
	}
}

export default connect(
	(state)=>{
		return {
			userinfo:state.userinfo,
			roominfo:state.clickroomprice
		}
	},
	{
		getroomprice(){
			return axios.get('/room/roomprice').then(res=>{
				return {
					type:'roomprice',
					payload:res.data
				}
			});
		}
	}
)(Updateroomprice);