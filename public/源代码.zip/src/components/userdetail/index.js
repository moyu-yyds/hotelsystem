import React,{Component} from "react";
import {connect} from "react-redux";

import { Form } from 'antd';
const FormItem = Form.Item;
 
class Userdetail extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 4 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return (
			<section id="userdetail">
				<div className="title">员工基本信息</div>
				<Form layout={formLayout}>
					<FormItem label="姓名：" {...formItemLayout} >
						{this.props.user.username}
					</FormItem>
					<FormItem label="性别：" {...formItemLayout} >
						{this.props.user.sex}
					</FormItem>
					<FormItem label="身份证号码：" {...formItemLayout} >
						{this.props.user.cardid}
					</FormItem>
					<FormItem label="手机号：" {...formItemLayout} >
						{this.props.user.phonenumber}
					</FormItem>
					<FormItem label="邮箱：" {...formItemLayout} >
						{this.props.user.email}
					</FormItem>
					<FormItem label="出生日期：" {...formItemLayout} >
						{this.props.user.birth}
					</FormItem>
					<FormItem label="居住地址：" {...formItemLayout} >
						{this.props.user.address}
					</FormItem>
				</Form>
			</section>	
			)
	}
}

export default connect(
	(state)=>{
		return {
			user:state.clickuser
		}
	},
	null
)(Userdetail);