import React,{Component} from "react";
import {connect} from "react-redux";

import { Table } from 'antd';

const pagination = {
	pageSize:6
}

class Usermanagement extends Component{
	constructor(){
		super();
		this.state = {
			columns : [
				{
				title: '员工姓名',
			  	dataIndex: 'name',
				}, 
				{
			 	title: '手机号码',
			  	dataIndex: 'phonenumber',
				},
			  	{
			  	 title:"操作1",
			  	 dataIndex:'view',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.view.bind(this,record.allinfo)}>{text}</span>
			  	},
			  	{ 
			  	 title:"操作2",
			  	 dataIndex:'reset',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.reset.bind(this,record.allinfo._id)}>{text}</span>
			  	},
			  	{
			  	 title:"操作3",
			  	 dataIndex:'remove',
			  	 className:'operation',
			  	 render:(text,record)=><span onClick={this.remove.bind(this,record.allinfo._id,record.allinfo.username)}>{text}</span>
			  	}
			],
			alluser:[]
		}
	}
	componentWillMount(){
		var alluser = [] ; 
		axios.get('/user/alluser').then(res=>{
			for(var i = 0 ; i < res.data.length ; i++){
				alluser.push({
					key:res.data[i]._id,
					name:res.data[i].username,
					phonenumber:res.data[i].phonenumber,
					view:'查看详情',
					reset:'重置密码',
					remove:'删除员工',
					//方便把信息传入详情页面
					allinfo:res.data[i]
				});
			}
			this.setState({alluser});
		});
	}
	render(){
		if(this.props.userinfo.username == '管理员'){
			return (
				<section id="usermanagement">
					<Table columns={this.state.columns} dataSource={this.state.alluser} bordered pagination={pagination}/>
				</section>
				)
		}else{
			return (
				<section id="permissions">
					您没有此项权限！
				</section>
				)
		}
	}
	view(items){
		this.props.getclickuser(items);
		this.props.history.push('/home/userdetail');
	}
	reset(id){
		axios.post('/user/changepassword',{id,wanted:'111111'}).then(res=>{
			alert('密码重置成功！');
		});
	}
	remove(id,name){
		if(name == '管理员'){
			alert("管理员账号不能被删除！");
		}else{
			console.log(id);
			axios.post('/user/removeuser',{id}).then(res=>{
				alert('删除成功！');
				var alluser = [] ; 
				//改变状态
				axios.get('/user/alluser').then(res=>{
					for(var i = 0 ; i < res.data.length ; i++){
						alluser.push({
							key:res.data[i]._id,
							name:res.data[i].username,
							phonenumber:res.data[i].phonenumber,
							view:'查看详情',
							reset:'重置密码',
							remove:'删除员工',
							allinfo:res.data[i]
						});
					}
					this.setState({alluser});
				});
			});
		}
	}
}

export default connect(
	(state)=>{
		return {
			alluser:state.alluser,
			userinfo:state.userinfo
		}
	},
	{
		getclickuser(items){
			return {
				type:'clickuser',
				payload:items
			}
		}
	}
)(Usermanagement) ;