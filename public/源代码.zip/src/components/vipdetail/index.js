import React,{Component} from 'react';
import {connect} from 'react-redux';
 
import { Form,List} from 'antd';
const FormItem = Form.Item;

class Vipdetail extends Component{
	constructor(){
		super();
		this.state = {
			formLayout: 'horizontal'
		}
	}
	render(){
		const { formLayout } = this.state;
		const formItemLayout = formLayout === 'horizontal' ? {
		      labelCol: { span: 6 },
		      wrapperCol: { span: 14 },
		    } : null;
		    const buttonItemLayout = formLayout === 'horizontal' ? {
		      wrapperCol: { span: 14, offset: 4 },
		    } : null;
		return ( 
			<section id="vipdetail">
				<div className="title">会员详细信息</div>
				<Form layout={formLayout}>
					<FormItem label="会员姓名：" {...formItemLayout} >
						{this.props.vipinfo.username}
					</FormItem>
					<FormItem label="身份证号码：" {...formItemLayout} >
						{this.props.vipinfo.usercardid}
					</FormItem>
					<FormItem label="会员类型：" {...formItemLayout} >
						{this.props.vipinfo.viptype}
					</FormItem>
					<FormItem label="会员余额：" {...formItemLayout} >
						{this.props.vipinfo.money}
					</FormItem>
					<div>
						<h3 style={{ marginBottom: 16 }}>交易记录</h3>
					    	<List
					    	      size="small"
					    	      bordered
					    	      dataSource={this.props.vipinfo.record}
					    	      renderItem={item => (<List.Item>{item}</List.Item>)} />
					</div>
				</Form>
			</section>
			)
	}
}

export default connect(
	(state)=>{
		return {
			vipinfo:state.vipinfo
		}
	},
	null
)(Vipdetail);