import React,{Component} from 'react';
import {connect} from 'react-redux';

import { Tabs,Table } from 'antd';
const TabPane = Tabs.TabPane;

function callback(key) {
	console.log(key);
} 
  
const pagination = {
	pageSize:6
}

class Vipmanagement extends Component{
	constructor(){
		super();
		this.state = {
			columns:[
				{
				title:'会员名',
				dataIndex:'name'
				},
				{
				title:'身份证号码',
				dataIndex:'cardid'
				},
				{
				title:'会员类型',
				dataIndex:'viptype'
				},
				{
				title:'操作1',
				dataIndex:'view',
				className:'operation',
				render:(text,record)=><span onClick={this.view.bind(this,record.allvipinfo)}>{text}</span>
				},
				{
				title:'操作2',
				dataIndex:'topup',
				className:'operation',
				render:(text,record)=><span onClick={this.topup.bind(this,record.allvipinfo)}>{text}</span>
				},
				{
				title:'操作3',
				dataIndex:'remove',
				className:'operation',
				render:(text,record)=><span onClick={this.remove.bind(this,record.allvipinfo)}>{text}</span>
				}
			],
			allvip:[],
			personvip:[],
			teamvip:[]
		}
	}
	componentWillMount(){
		var personvip = [];
		var teamvip = [];
		var allvip = [];
		axios.get('/resident/allpersonvip').then(resone=>{
			for(var i = 0 ; i < resone.data.length ; i++){
				personvip.push({
					key:resone.data[i]._id,
					name:resone.data[i].username,
					cardid:resone.data[i].usercardid,
					viptype:resone.data[i].viptype,
					allvipinfo:resone.data[i],
					view:'查看详情',
					topup:'充值',
					remove:'退卡'
				});
				allvip.push(personvip[i]);
			}
			axios.get('/resident/allteamvip').then(restwo=>{
				for(var i = 0 ; i < restwo.data.length ; i++){
					teamvip.push({
						key:restwo.data[i]._id,
						name:restwo.data[i].username,
						cardid:restwo.data[i].usercardid,
						viptype:restwo.data[i].viptype,
						allvipinfo:restwo.data[i],
						view:'查看详情',
						topup:'充值',
						remove:'退卡'
					});
					allvip.push(teamvip[i]);
				}
				this.setState({allvip,personvip,teamvip});
			});
		});	
	}
	render(){
		return (
			<section id="vipmanagement">
				<Tabs defaultActiveKey="1" onChange={callback}>
					<TabPane tab="全部会员" key="1">
						<Table columns={this.state.columns} dataSource={this.state.allvip} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="个人会员" key="2">
						<Table columns={this.state.columns} dataSource={this.state.personvip} bordered pagination={pagination}/>
					</TabPane>
					<TabPane tab="团体会员" key="3">
						<Table columns={this.state.columns} dataSource={this.state.teamvip} bordered pagination={pagination}/>
					</TabPane>
				</Tabs>
			</section>
			)
	}
	view(item){
		this.props.getvipinfo(item);
		this.props.history.push('/home/vipdetail');
	}
	topup(item){
		this.props.getvipinfo(item);
		this.props.history.push('/home/topup?1');
	}
	remove(item){
		axios.post('/resident/removevip',{item:JSON.stringify(item)}).then(res=>{
			if(item.viptype == '个人'){
				var personvip = [];
				var allvip = [];
				axios.get('/resident/allpersonvip').then(res=>{
					for(var i = 0 ; i < res.data.length ; i++){
						personvip.push({
							key:res.data[i]._id,
							name:res.data[i].username,
							cardid:res.data[i].usercardid,
							viptype:res.data[i].viptype,
							allvipinfo:res.data[i],
							view:'查看详情',
							topup:'充值',
							remove:'退卡'
						});
						allvip.push(personvip[i]);
					}
					for(var i = 0 ; i < this.state.teamvip.length ; i++){
						allvip.push(this.state.teamvip[i]);
					}
					this.setState({allvip,personvip});
					alert('退卡成功！');
				});		
			}else if(item.viptype == '团体'){
				var teamvip = [];
				var allvip = [];
				axios.get('/resident/allteamvip').then(res=>{
					for(var i = 0 ; i <res.data.length ; i++){
						teamvip.push({
							key:res.data[i]._id,
							name:res.data[i].username,
							cardid:res.data[i].usercardid,
							viptype:res.data[i].viptype,
							allvip:res.data[i],
							view:'查看详情',
							topup:'充值',
							remove:'退卡'
						});
						allvip.push(teamvip[i]);
					}
					for(var i = 0 ; i < this.state.personvip.length; i++){
						allvip.push(this.state.personvip[i]);
					}
					this.setState({allvip,teamvip});
					alert('删除成功！');
				});		
			}			
		});
	}
}

export default connect(
	null,
	{
		getvipinfo(item){
			return {
				type:'vipinfo',
				payload:item
			}
		}
	}
)(Vipmanagement);