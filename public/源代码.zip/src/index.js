import React from "react";
import ReactDOM from "react-dom";
import 'antd/dist/antd.css';  

import router from "./router";


ReactDOM.render(router,document.getElementById("bigbox"));