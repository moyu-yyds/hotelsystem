const userinfo = (state={},info)=>{
	let {type,payload} = info ;
	switch(type){
		case 'userinfo' : return payload ;
		default : return state ;
	}
}

const alluser = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'alluser' : return payload ;
		default : return state ;
	}
}

const clickuser = (state = {} , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'clickuser' : return payload ;
		default : return state ;
	}
}

const roomprice = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'roomprice' : return payload ;
		default : return state ;
	}
}

const clickroomprice = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'clickroomprice' : return payload ;
		default : return state ;
	}
}

const allroom = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'allroom' : return payload ;
		default : return state ;
	}
}

const restroom = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'restroom' : return payload ;
		default : return state ;
	}
}

const chosenroom = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'chosenroom' : return payload ;
		default : return state ;
	}
}

const reservationnum = (state = '0' , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'reservationnum' : return payload ;
		default : return state ;
	}
}

const allreservation = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'allreservation' : return payload ;
		default : return state ;
	}
}

const reservationinfo = (state = {} , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'reservationinfo' : return payload ;
		default : return state ;
	}
}

const reservationitem = (state = {} , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'reservationitem' : return payload ;
		default : return state ;
	}
}

const restmaintenperson = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'restmaintenperson' : return payload;
		default : return state;
	}
}

const allmaintenperson = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'allmaintenperson' : return payload;
		default : return state;
	}
}

const restcleanperson = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'restcleanperson' : return payload;
		default : return state;
	}
}

const allcleanperson = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'allcleanperson' : return payload;
		default : return state;
	}
}

const allresident = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'allresident' : return payload;
		default : return state;
	}
}

const memregbaseinfo = (state = {} , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'memregbaseinfo' : return payload;
		default : return state;
	}
}

const basecheckin = (state = {} , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'basecheckin' : return payload ;
		default : return state ;
	}
}

const allpersonvip = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'allpersonvip' : return payload ;
		default : return state ;
	}
}

const allteamvip = (state = [] , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'allteamvip' : return payload ;
		default : return state ;
	}
}

const vipinfo = (state = {} , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'vipinfo' : return payload ;
		default : return state ;
	}
}

const clickcheckin = (state = {} , info) => {
	let {type,payload} = info ;
	switch(type){
		case 'clickcheckin' : return payload ;
		default : return state ;
	}
}

export {userinfo,alluser,clickuser,roomprice,clickroomprice,allroom,restroom,chosenroom,reservationnum,allreservation,reservationinfo,reservationitem,restmaintenperson,allmaintenperson,restcleanperson,allcleanperson,allresident,memregbaseinfo,basecheckin,allpersonvip,allteamvip,vipinfo,clickcheckin};