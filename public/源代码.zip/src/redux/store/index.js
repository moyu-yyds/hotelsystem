import {createStore,combineReducers,applyMiddleware} from "redux";
import reduxpromise from "redux-promise";

import {userinfo,alluser,clickuser,roomprice,clickroomprice,allroom,restroom,chosenroom,reservationnum,allreservation,reservationinfo,reservationitem,restmaintenperson,allmaintenperson,restcleanperson,allcleanperson,allresident,memregbaseinfo,basecheckin,allpersonvip,allteamvip,vipinfo,clickcheckin} from "../reducer" ;

const store = createStore(combineReducers({
	userinfo,
	alluser,
	clickuser,
	roomprice,
	clickroomprice,
	allroom,
	restroom,
	chosenroom,
	reservationnum,
	allreservation,
	reservationinfo,
	reservationitem,
	restmaintenperson,
	allmaintenperson,
	restcleanperson,
	allcleanperson,
	allresident,
	memregbaseinfo,
	basecheckin,
	allpersonvip,
	allteamvip,
	vipinfo,
	clickcheckin
}),applyMiddleware(reduxpromise));

export default store ;