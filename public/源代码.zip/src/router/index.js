import React from "react";
import {BrowserRouter as Router,Route,Switch,Redirect} from "react-router-dom";

import {Provider} from "react-redux";
import store from "../redux/store";

import App from "../components/app";
import Home from "../components/home";
import Login from "../components/login";
import Register from "../components/register";
import Changepassword from "../components/changepassword";
import Usermanagement from "../components/usermanagement";
import Userdetail from "../components/userdetail";
import Roomprice from "../components/roomprice";
import Updateroomprice from "../components/updateroomprice";
import Room from "../components/room";
import Preservation from "../components/preservation";
import Treservation from "../components/treservation";
import Reservationdetail from "../components/reservationdetail";
import Chooseroom from "../components/chooseroom";
import Maintenance from "../components/maintenance";
import Maintenmanage from "../components/maintenmanage";
import Clean from "../components/clean";
import Cleanmanage from "../components/cleanmanage";
import Memregister from "../components/memregister";
import Memreginfo from "../components/memreginfo";
import Checkin from "../components/checkin";
import Checkinbaseinfo from "../components/checkinbaseinfo";
import Personcheckin from "../components/personcheckin";
import Vipmanagement from "../components/vipmanagement";
import Topup from "../components/topup";
import Vipdetail from "../components/vipdetail";
import Resermanage from "../components/resermanage";
import Pchrecord from "../components/pchrecord";
import Tchrecord from "../components/tchrecord";
import Checkindetail from "../components/checkindetail";
import Pcheckout from "../components/pcheckout";
import Tcheckout from "../components/tcheckout";
import Checkout from "../components/checkout";
import Dealbaddebt from "../components/dealbaddebt";
import Owedebt from "../components/owedebt";

export default (
	<Provider store={store}>
		<Router>
			<App>
				<Switch>
					<Route path="/login" component={Login} />
					<Route path="/home" render={()=>
						<Home>
							<Route path="/home/roomprice" component={Roomprice}/>
							<Route path="/home/updateroomprice" component={Updateroomprice}/>
							<Route path="/home/register" component={Register} />
							<Route path="/home/changepassword" component={Changepassword} />
							<Route path="/home/usermanagement" component={Usermanagement} />
							<Route path="/home/userdetail" component={Userdetail} />
							<Route path='/home/room' component={Room} />
							<Route path='/home/preservation' component={Preservation} />
							<Route path='/home/treservation' component={Treservation} />
							<Route path="/home/reservationdetail" component={Reservationdetail} />
							<Route path='/home/chooseroom' component={Chooseroom} />
							<Route path="/home/maintenance" component={Maintenance} />
							<Route path="/home/maintenmanage" component={Maintenmanage} />
							<Route path="/home/clean" component={Clean} />
							<Route path="/home/cleanmanage" component={Cleanmanage} />
							<Route path="/home/Memregister" component={Memregister}/>
							<Route path="/home/memreginfo" component={Memreginfo} />
							<Route path="/home/checkin" component={Checkin} />
							<Route path="/home/checkinbaseinfo" component={Checkinbaseinfo} />
							<Route path="/home/personcheckin" component={Personcheckin} />
							<Route path="/home/vipmanagement" component={Vipmanagement} />
							<Route path="/home/topup" component={Topup} />
							<Route path="/home/vipdetail" component={Vipdetail} />
							<Route path="/home/resermanage" component={Resermanage} />
							<Route path="/home/pchrecord" component={Pchrecord} />
							<Route path="/home/tchrecord" component={Tchrecord} />
							<Route path="/home/checkindetail" component={Checkindetail} />
							<Route path="/home/pcheckout" component={Pcheckout} />
							<Route path="/home/tcheckout" component={Tcheckout} />
							<Route path="/home/checkout" component={Checkout} />
							<Route path="/home/dealbaddebt" component={Dealbaddebt} />
							<Route path="/home/owedebt" component={Owedebt} />
						</Home>
					} />
					<Redirect from="*" to="/login" />
				</Switch>
			</App>
		</Router>
	</Provider>
)